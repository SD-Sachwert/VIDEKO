Inhalt:
- images/01_grob_planen.png
- images/02_rueckruf.png
- images/03_direkt_ins_studio.png
- PROMPTS.txt

Einsatz:
Die drei Bilder sind für die Kontakt-/Entscheidungssektion vor dem Terminformular gedacht.
Die Prompts können für spätere Reproduktionen oder Variationen in Bildtools verwendet werden.
