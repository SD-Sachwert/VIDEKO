Inhalt dieses ZIP:
- assets/REFERENZ_STYLEFINDER_LAYOUT.png = Layout-Referenz
- assets/01_modern.png bis 06_luxurioes.png = Einzelbilder für die Style-Karten
- PROMPT_CLAUDE_STYLEFINDER.txt = fertiger Prompt für Claude

Empfehlung:
1. ZIP entpacken
2. Referenzbild + Prompt + Assets an Claude geben
3. Claude soll nur die bestehende Stylefinder-Sektion ersetzen
