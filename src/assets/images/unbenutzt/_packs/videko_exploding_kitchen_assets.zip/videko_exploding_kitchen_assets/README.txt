VIDEKO Exploding Kitchen Asset-Paket

Ordner:
/assets = alle Bilder
CLAUDE_PROMPT_EXPLODING_KITCHEN.md = kompletter Prompt für Claude

Hinweis:
Der Hero/Banner oben auf der Landingpage soll unangetastet bleiben. Die neue Exploding-Kitchen-Sektion wird in den hellen Mittelteil eingefügt.
