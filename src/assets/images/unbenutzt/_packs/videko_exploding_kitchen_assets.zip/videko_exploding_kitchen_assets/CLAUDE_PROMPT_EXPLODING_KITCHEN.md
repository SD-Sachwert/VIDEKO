# VIDEKO Landingpage – Exploding Kitchen Sektion einbauen

## Ziel
Baue auf der VIDEKO Landingpage eine neue Premium-Sektion „Exploding Kitchen“ ein. Der obere Hero/Banner mit Video bleibt unverändert. Die neue Sektion soll in den hellen Mittelteil der Landingpage integriert werden und als starker Wow-Moment funktionieren.

Die Sektion soll zeigen: Eine schöne Küche ist nicht einfach nur eine schöne Küche. Dahinter stecken Material, Stauraum, Licht, Technik, Ergonomie, Montage und viele präzise Entscheidungen.

Leitidee:

**Was Sie sehen: eine Küche.  
Was wir sehen: 187 Entscheidungen.**

Das Ding soll wirken wie ein Luxus-Uhrwerk, das sich beim Scrollen kontrolliert auseinanderfaltet. Nicht wildes Transformers-Geballer, sondern präzise, hochwertig, sauber. Premium, nicht Kirmes.

---

## Mitgelieferte Assets
Lege alle Bilder aus dem Ordner `/assets` in euren Projektordner, zum Beispiel:

`/public/images/exploding-kitchen/`

Dateien:

```text
00-reference-section-target-look.png
01-kueche-assembled-desktop.png
02-kueche-exploded-overview-desktop.png
03-layer-arbeitsplatte.png
04-layer-rahmen-licht.png
05-layer-korpus-fronten.png
06-layer-stauraum-schubladen.png
07-layer-technik-geraete.png
08-layer-sockel-basis.png
09-overlay-light-streaks.png
10-overlay-shadow-depth.png
```

Wichtig:
- `00-reference-section-target-look.png` ist nur die optische Zielreferenz.
- `01-kueche-assembled-desktop.png` ist der Start-/Endzustand.
- `02-kueche-exploded-overview-desktop.png` ist Fallback und visuelle Referenz.
- `03` bis `08` sind die Layer für die Animation.
- `09` und `10` sind Effekte/Overlays.

Falls einzelne Layer nicht perfekt transparent sind: bitte per CSS sauber freistellen/integrieren, mit Mix-Blend, Masking oder hellem Section-Hintergrund. Keine hässlichen Kanten. Keine sichtbaren Checkerboard-Flächen. Wenn ein Layer nicht sauber genug ist, nutze ihn trotzdem als visuelle Ebene, aber blende ihn weich ein und arbeite mit `mix-blend-mode: multiply/screen` nur, wenn es optisch passt.

---

## Platzierung auf der Landingpage
Die Exploding-Kitchen-Sektion soll nach den ersten hellen Einführungs-/Leistungsbereichen eingefügt werden. Nicht direkt im Hero. Der bestehende obere Videobanner bleibt unangetastet.

Empfohlene Position:
- Nach dem ersten starken Einstieg/Leistungsbereich
- Vor Stylefinder oder Qualitäts-/Warum-VIDEKO-Bereich

Die Sektion soll auf Desktop groß wirken und mindestens eine volle Bildschirmhöhe einnehmen.

---

## Desktop-Aufbau

### Section-Grundstruktur
Baue eine eigene Section:

```html
<section class="exploding-kitchen-section">
  <div class="exploding-kitchen-sticky">
    <div class="exploding-copy">...</div>
    <div class="exploding-stage">...</div>
    <div class="exploding-info">...</div>
    <div class="exploding-progress">...</div>
  </div>
</section>
```

### Layout
Desktop ab 1024px:

- Hintergrund: warmes Creme / Ivory, passend zur VIDEKO-Seite
- Links: Headline und kurzer Text
- Mitte: große Küche / Layer-Bühne
- Rechts: wechselnde Infokarten
- Unten: Step-/Progress-Navigation und CTA

Visuelle Richtung:
- hell, clean, luxuriös
- Serif-Headline wie restliche VIDEKO-Seite
- Gold-Akzente
- weiche Schatten
- dezente Lichtspuren
- keine dunkle Sektion mitten im hellen Seitenbereich

---

## Texte

### Eyebrow
`TECHNIK, DIE MAN NICHT SIEHT`

### Headline
```text
Was Sie sehen:
eine Küche.
Was wir sehen:
187 Entscheidungen.
```

`187 Entscheidungen` in Gold hervorheben.

### Subline
```text
Material, Licht, Stauraum, Ergonomie, Technik und Montage – bei uns greift alles ineinander.
```

### Kleiner Zusatztext
```text
Jede Ebene ist durchdacht.
Jedes Detail hat seinen Grund.
Für Küchen, die bleiben.
```

---

## Infokarten rechts
Baue 4 wechselnde Feature-Cards. Sie sollen synchron zur Scrollphase wechseln.

### 1. Materialien
Titel: `Materialien`  
Text: `Echte Materialien. Perfekt aufeinander abgestimmt.`

### 2. Stauraum
Titel: `Stauraum`  
Text: `Intelligent organisiert. Für mehr Platz und Überblick.`

### 3. Lichtkonzept
Titel: `Lichtkonzept`  
Text: `Atmosphäre trifft Funktion. Für jede Stimmung das richtige Licht.`

### 4. Präzise Montage
Titel: `Präzise Montage`  
Text: `Millimetergenaue Planung. Saubere Umsetzung. Langlebige Perfektion.`

Optional weitere Micro-Labels:
- `Ergonomie`
- `Geräteintegration`
- `Innenorganisation`
- `Service danach`

---

## Progress unten
Baue eine dezente Step-Leiste:

```text
01 Schön        Ästhetik & Design
02 Exploded     Was dahinter steckt
03 Technik      Intelligenz & Innovation
04 Perfektion   Montage & Service
```

Aktiver Step wird gold hervorgehoben.

---

## CTA
Button:

`BERATUNG ANFRAGEN →`

Darunter kleiner Trust-Hinweis:

`Persönlich. Unverbindlich. Auf Augenhöhe.`

---

## Animation / Motion
Nutze bevorzugt GSAP + ScrollTrigger. Falls GSAP nicht im Projekt ist, bitte installieren oder alternativ Framer Motion nutzen. Wichtig ist die Wirkung, nicht das Framework-Ego.

### Sticky Scroll
Die Section soll eine Scroll-Strecke haben, z. B. 300vh bis 420vh.

```css
.exploding-kitchen-section {
  position: relative;
  min-height: 380vh;
  background: #f7f1e6;
}

.exploding-kitchen-sticky {
  position: sticky;
  top: 0;
  height: 100vh;
  overflow: hidden;
}
```

### Startzustand
Am Anfang:
- `01-kueche-assembled-desktop.png` sichtbar
- Layer (`03` bis `08`) sind exakt darüber/zentral positioniert, aber unsichtbar oder stark zusammengefahren
- Overlay `09` sehr subtil sichtbar
- Overlay `10` unter der Küche als weicher Schatten

### Explode-Phase
Beim Scrollen:
- assembled image weich ausblenden
- Layer einblenden
- Layer fahren auseinander
- Bewegungen nicht zu groß, sondern geordnet und edel

Empfohlene Desktop-Bewegungen:

```js
const layerMotion = {
  arbeitsplatte: { y: -135, x: 0, scale: 1.02 },
  rahmen:       { y: -65,  x: 0, scale: 1.01 },
  korpus:       { y: 0,    x: 0, scale: 1.0 },
  stauraum:     { y: 85,   x: -10, scale: 1.0 },
  technik:      { y: 155,  x: 12, scale: 0.99 },
  sockel:       { y: 220,  x: 0, scale: 0.98 }
}
```

Zusätzlich:
- leichte Parallax-Bewegung je Layer
- Schatten werden mit zunehmender Explosion stärker
- Light-Streak-Overlay fährt langsam horizontal mit
- Hotspots erscheinen nacheinander
- rechte Infokarte wechselt passend zur aktiven Phase
- Step-Leiste unten aktualisiert den aktiven Zustand

### Reassemble-Phase
Am Ende:
- Layer fahren wieder enger zusammen oder die exploded overview blendet weich in assembled image zurück
- CTA wird stärker sichtbar
- Endzustand soll ruhig, hochwertig und abgeschlossen wirken

---

## Konkrete Layer-HTML-Struktur

```html
<div class="kitchen-stage">
  <img class="shadow-depth" src="/images/exploding-kitchen/10-overlay-shadow-depth.png" alt="" />
  <img class="light-streaks" src="/images/exploding-kitchen/09-overlay-light-streaks.png" alt="" />

  <img class="kitchen-assembled" src="/images/exploding-kitchen/01-kueche-assembled-desktop.png" alt="Luxuriöse VIDEKO Küche" />

  <div class="kitchen-layers" aria-hidden="true">
    <img class="layer layer-countertop" src="/images/exploding-kitchen/03-layer-arbeitsplatte.png" alt="" />
    <img class="layer layer-frame" src="/images/exploding-kitchen/04-layer-rahmen-licht.png" alt="" />
    <img class="layer layer-shell" src="/images/exploding-kitchen/05-layer-korpus-fronten.png" alt="" />
    <img class="layer layer-storage" src="/images/exploding-kitchen/06-layer-stauraum-schubladen.png" alt="" />
    <img class="layer layer-technical" src="/images/exploding-kitchen/07-layer-technik-geraete.png" alt="" />
    <img class="layer layer-base" src="/images/exploding-kitchen/08-layer-sockel-basis.png" alt="" />
  </div>
</div>
```

Alle Layer müssen absolut übereinander liegen:

```css
.kitchen-stage {
  position: relative;
  width: min(68vw, 1120px);
  aspect-ratio: 16 / 9;
}

.kitchen-stage img {
  position: absolute;
  inset: 0;
  width: 100%;
  height: 100%;
  object-fit: contain;
  pointer-events: none;
  user-select: none;
}
```

Bei den Layern eventuell `object-fit: contain` behalten und mit `transform-origin: center center` arbeiten.

---

## Beispiel GSAP-Logik
Passe Klassennamen ans Projekt an.

```js
import gsap from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';

gsap.registerPlugin(ScrollTrigger);

export function initExplodingKitchen() {
  const section = document.querySelector('.exploding-kitchen-section');
  if (!section) return;

  const tl = gsap.timeline({
    scrollTrigger: {
      trigger: section,
      start: 'top top',
      end: 'bottom bottom',
      scrub: 1.1,
    }
  });

  tl.set('.kitchen-layers .layer', { opacity: 0, y: 0, x: 0, scale: 1 });
  tl.set('.kitchen-assembled', { opacity: 1 });

  // Phase 1: Einstieg
  tl.to('.exploding-copy', { opacity: 1, y: 0, duration: 0.4 });
  tl.to('.light-streaks', { opacity: 0.35, xPercent: 5, duration: 0.4 }, '<');

  // Phase 2: Wechsel zu Layern
  tl.to('.kitchen-assembled', { opacity: 0, duration: 0.35 });
  tl.to('.kitchen-layers .layer', { opacity: 1, duration: 0.35 }, '<');

  // Phase 3: Explode
  tl.to('.layer-countertop', { y: -135, scale: 1.02, duration: 0.8 }, '<');
  tl.to('.layer-frame', { y: -65, scale: 1.01, duration: 0.8 }, '<');
  tl.to('.layer-shell', { y: 0, duration: 0.8 }, '<');
  tl.to('.layer-storage', { y: 85, x: -10, duration: 0.8 }, '<');
  tl.to('.layer-technical', { y: 155, x: 12, scale: 0.99, duration: 0.8 }, '<');
  tl.to('.layer-base', { y: 220, scale: 0.98, duration: 0.8 }, '<');

  // Infokarten / Steps einblenden
  tl.to('.exploding-info-card', { opacity: 1, y: 0, stagger: 0.08, duration: 0.35 }, '-=0.45');
  tl.to('.hotspot', { opacity: 1, scale: 1, stagger: 0.08, duration: 0.3 }, '<');

  // Phase 4: Premium-Details
  tl.to('.light-streaks', { opacity: 0.55, xPercent: 14, duration: 0.6 });
  tl.to('.shadow-depth', { opacity: 0.75, scale: 1.04, duration: 0.6 }, '<');

  // Phase 5: CTA
  tl.to('.exploding-cta', { opacity: 1, y: 0, duration: 0.35 });
}
```

Wenn React/Next verwendet wird:
- Init in `useEffect`
- Cleanup mit `ScrollTrigger.getAll().forEach(t => t.kill())`
- `gsap.context()` verwenden, damit keine Memory-Leichen rumliegen wie in einer schlechten Möbelhausdatenbank.

---

## Hotspots
Hotspots bitte als HTML/CSS/SVG bauen, nicht als Bild.

- kleine goldene Punkte
- feine dotted lines zu Infokarten
- sanftes Pulsieren
- nur auf Desktop sichtbar
- auf Mobile weglassen oder stark reduzieren

CSS-Beispiel:

```css
.hotspot {
  position: absolute;
  width: 10px;
  height: 10px;
  border-radius: 999px;
  background: #b6924b;
  box-shadow: 0 0 0 8px rgba(182,146,75,.12), 0 0 24px rgba(182,146,75,.35);
  opacity: 0;
  transform: scale(.7);
}

.hotspot::after {
  content: '';
  position: absolute;
  inset: -10px;
  border-radius: inherit;
  border: 1px solid rgba(182,146,75,.35);
  animation: hotspotPulse 2.4s ease-out infinite;
}

@keyframes hotspotPulse {
  0% { transform: scale(.7); opacity: .7; }
  100% { transform: scale(1.8); opacity: 0; }
}
```

---

## Motion Details, damit es teuer wirkt
Bitte keine hektischen Effekte.

Richtig:
- langsame, kontrollierte Bewegungen
- `ease: power2.out` oder `power3.out`
- Layer leicht zeitversetzt
- Licht nur subtil
- Schatten sauber
- Cards weich rein

Falsch:
- alles fliegt wild auseinander
- Bounce-Effekte
- billige Particle-Explosion
- zu viele blinkende Elemente
- harte Übergänge

Das soll aussehen wie ein Luxus-Auto-Konfigurator, nicht wie ein Toaster nach Kurzschluss.

---

## Mobile Verhalten
Mobile nicht denselben Desktop-Wahnsinn reinquetschen.

Unter 768px:
- keine sticky 380vh Monstersektion
- nutze `02-kueche-exploded-overview-desktop.png` oder `01-kueche-assembled-desktop.png` als statisches/leicht animiertes Bild
- Infokarten darunter als Swipe-/Accordion-Cards
- leichte Fade-/Slide-Animationen beim Scrollen
- Hotspots optional, aber bitte sparsam
- CTA sichtbar und schnell erreichbar

Mobile Layout:

```text
Headline
Subline
Küche-Bild
4 Infokarten als Slider oder Accordion
CTA
```

CSS:

```css
@media (max-width: 767px) {
  .exploding-kitchen-section {
    min-height: auto;
    padding: 80px 20px;
  }

  .exploding-kitchen-sticky {
    position: relative;
    height: auto;
  }

  .kitchen-stage {
    width: 100%;
    margin: 32px 0;
  }

  .kitchen-layers {
    display: none;
  }

  .kitchen-assembled {
    opacity: 1 !important;
    position: relative;
  }
}
```

---

## Performance
Wichtig, sonst sieht es am Ende gut aus und lädt wie ein nasser Sack Zement.

- Bilder lazy laden, aber die ersten sichtbaren Assets dieser Sektion rechtzeitig preloaden
- `will-change: transform, opacity` nur für animierte Layer
- keine riesigen unkomprimierten PNGs im Livebetrieb verwenden
- WebP/AVIF erzeugen, wenn möglich
- `prefers-reduced-motion` beachten

Reduced Motion:

```css
@media (prefers-reduced-motion: reduce) {
  .kitchen-layers {
    display: none;
  }
  .kitchen-assembled {
    opacity: 1 !important;
  }
}
```

---

## Integration in bestehendes Design
Die Sektion muss wie VIDEKO wirken:

- Creme/heller Hintergrund wie aktuelle helle Mittelbereiche
- Gold: warm, nicht gelb
- Schwarz/Anthrazit sparsam für Text und technische Akzente
- Große Serif-Headlines
- Ruhige Sans-Texte
- Buttons wie auf restlicher Seite
- Kein harter dunkler Block mitten in der Landingpage
- Oberer Video-Hero bleibt unverändert
- Unterer dunkler Abschluss bleibt unverändert

---

## Abnahme-Kriterien
Die Sektion ist erst fertig, wenn:

1. Oben der Video-Hero unverändert bleibt.
2. Die Exploding Kitchen in den hellen Mittelteil eingefügt ist.
3. Desktop eine echte sticky Scroll-Animation hat.
4. Die Küche zuerst fertig wirkt, sich dann kontrolliert in Ebenen öffnet.
5. Infokarten und Step-Leiste synchron zur Animation wirken.
6. Kein Text über Bildern klebt oder unlesbar wird.
7. Mobile nicht kaputtläuft und keine horizontale Scroll-Seuche entsteht.
8. Performance akzeptabel bleibt.
9. Die Sektion nach Premium riecht und nicht nach „Plugin aus 2018“.

---

## Kurzfassung für die Umsetzung
Baue eine helle, sticky, scrollanimierte Exploding-Kitchen-Sektion mit den gelieferten Layer-Bildern. Start: fertige Küche. Scroll: Layer fahren auseinander. Rechts erscheinen passende Infokarten. Unten Step-Leiste und CTA. Mobile bekommt eine vereinfachte Version. Der obere Videobanner bleibt unangetastet.
