# Animation Checklist für Claude

- [ ] Section-Reveals per IntersectionObserver / Framer Motion
- [ ] Karten-Reveals gestaffelt
- [ ] Hover-Lift für Cards
- [ ] Bild-Zoom bei Hover
- [ ] Gold-Shine über wichtige Cards
- [ ] Goldlinien zeichnen sich beim Scroll ein
- [ ] Exploding Kitchen Callouts erscheinen nacheinander
- [ ] Exploding Kitchen wirkt sticky oder zumindest groß animiert
- [ ] Stylefinder Device fährt rein
- [ ] Style-Cards swipen/revealen horizontal
- [ ] Studio-Galerie mit Pfeilen oder horizontalem Scroll
- [ ] Before/After Slider echt bedienbar oder simuliert animiert
- [ ] Prozesslinie zeichnet sich von links nach rechts
- [ ] Team-Cards Carousel-Gefühl
- [ ] Reduced-motion Fallback
