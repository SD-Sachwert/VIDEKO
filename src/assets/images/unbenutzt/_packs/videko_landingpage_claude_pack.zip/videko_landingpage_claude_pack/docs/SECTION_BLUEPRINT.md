# Section Blueprint – weißer Mittelteil

## Reihenfolge
1. Startpfade: links Text, rechts 3 versetzte Karten
2. Exploding Kitchen: links Text, Mitte große exploded kitchen, rechts Callouts
3. VIDEKO Unterschied: links Headline, rechts Feature-Cards + Highlight
4. Stylefinder: links Textcard, Mitte Device UI, rechts Style-Cards
5. Studio: links Text, rechts horizontale Galerie mit Highlight-Karte
6. Vorher/Nachher: links Text, rechts Slider + Stats
7. Prozess: links Headline, rechts Timeline 6 Steps
8. Team: links Text, rechts Portrait-Cards
9. Journal: links Text, rechts 4 Artikelkarten

## Wichtigster visueller Fokus
Die Exploding Kitchen Section muss der größte Wow-Block im weißen Bereich sein.

## Referenz
Siehe `assets/reference_white_middle_target.png`.
