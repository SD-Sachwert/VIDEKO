# Claude Prompt – VIDEKO Landingpage exakt nach Referenz umbauen

Du arbeitest an der bestehenden VIDEKO-Website. Bitte baue **nur den mittleren weißen Bereich der Landingpage** komplett neu, exakt nach der beigefügten Referenz `assets/reference_white_middle_target.png`.

## Wichtigste Regel

**Der aktuelle dunkle Hero/Banner oben bleibt wie er aktuell auf der Website ist.**  
**Der dunkle Abschluss/CTA + Footer unten bleibt ebenfalls dunkel und darf optisch ähnlich bleiben.**  
**Alles dazwischen wird neu gebaut und muss sich sehr eng am Referenzbild orientieren.**

Aktuell ist die Seite zu statisch, zu brav und ohne Effekte. Das Ziel ist eine hochwertige, helle, lebendige Premium-Experience mit viel Bewegung beim Scrollen.

---

# 1. Globales Layout für den weißen Mittelteil

Der gesamte Mittelteil bekommt einen warmen, hellen Premium-Look:

- Hintergrund: warmes Ivory / Creme, nicht reines Weiß.
- Sehr dezente Papier-/Steintextur oder radialer Soft-Gradient.
- Goldene, feine Linien im Hintergrund, sehr subtil.
- Viel Weißraum, aber die Inhalte dürfen nicht klein oder verloren wirken.
- Max-Width für Content: ca. `1180px` bis `1280px`.
- Section Padding Desktop: meistens `96px 24px`, bei großen Feature-Sections `120px 24px`.
- Mobile: alles sauber untereinander, Padding `56px 20px`.

Farben ungefähr:

```css
--videko-black: #070706;
--videko-ivory: #f6f1e8;
--videko-cream: #fbf7ee;
--videko-card: rgba(255,255,255,0.72);
--videko-gold: #b8954f;
--videko-gold-soft: #d8c28b;
--videko-text: #16130f;
--videko-muted: #7b7165;
--videko-border: rgba(120,95,45,0.18);
```

Alle Karten:

```css
border-radius: 18px;
box-shadow: 0 22px 70px rgba(45, 35, 20, 0.10);
border: 1px solid rgba(120, 95, 45, 0.16);
backdrop-filter: blur(12px);
```

Typografie:

- Große Headlines serif/elegant wie aktuell.
- Kleine Overline-Texte uppercase, letter-spacing `0.16em`, gold/braun.
- Bodytexte kurz, sauber, nicht zu viel Text.

---

# 2. Animation-Grundregeln

Bitte echte Scroll-Animationen einbauen. Keine reine statische Seite.

Wenn im Projekt `framer-motion` vorhanden ist: nutze Framer Motion.  
Wenn nicht vorhanden: nutze CSS + IntersectionObserver.  
Falls GSAP bereits im Projekt installiert ist, darfst du GSAP/ScrollTrigger nutzen, aber bitte keine neue schwere Library installieren, wenn nicht nötig.

## Standard-Reveal für Sections

Jede Section bekommt beim Scrollen einen dezenten Reveal:

- Start: `opacity: 0`, `transform: translateY(46px) scale(0.985)`
- Ende: `opacity: 1`, `transform: translateY(0) scale(1)`
- Duration: `700ms`
- Easing: `cubic-bezier(.22,1,.36,1)`
- Stagger innerhalb von Karten: `80ms` bis `130ms`

## Bild-Effekte

Bilder sollen leben:

- Parallax minimal: Bild bewegt sich beim Scrollen `translateY(-16px bis +16px)`.
- Hover: Bild leicht `scale(1.045)`, Overlay minimal heller, Goldlinie leuchtet.
- Cards bekommen Hover-Lift: `translateY(-8px)`, Shadow stärker.

## Gold-Light-Effekt

Auf wichtigen Cards und Buttons:

- eine sehr dezente Gold-Glow-Kante beim Hover.
- optional `::before`-Shine, der diagonal über die Card fährt.

Beispiel:

```css
.card::before {
  content: "";
  position: absolute;
  inset: 0;
  background: linear-gradient(120deg, transparent 0%, rgba(216,194,139,.22) 45%, transparent 65%);
  transform: translateX(-120%);
  transition: transform .9s ease;
  pointer-events: none;
}
.card:hover::before { transform: translateX(120%); }
```

## Reduced Motion beachten

Bei `prefers-reduced-motion: reduce` Animationen abschalten oder stark reduzieren.

---

# 3. Exakte Sections im weißen Mittelteil

## Section A – Einstieg: „Ihr Weg zur Küche, die zu Ihnen passt.“

Direkt unter dem aktuellen dunklen Hero beginnt der helle Bereich.

Layout wie Referenz:

- Links ein Textblock, ca. 25–30% Breite.
- Rechts drei große, versetzte Karten im 3D-/Carousel-Look.
- Karten sind nicht langweilig gleich ausgerichtet, sondern leicht versetzt:
  - Karte 1 dunkel, etwas nach unten/links.
  - Karte 2 hell, zentral und minimal größer/heller.
  - Karte 3 dunkel, etwas nach oben/rechts.
- Große transparente Zahlen `01`, `02`, `03` oben in den Karten.

Text links:

```text
IHR WEG ZUR KÜCHE,
DIE ZU IHNEN PASST.

In 3 Schritten
zur Traumküche.

Drei Wege. Ein Ziel:
Ihre perfekte Küche.
```

Karten:

1. `01 Inspiration finden`  
   Text: `Entdecken Sie Designs, Materialien und Küchenwelten.`  
   Link: `INSPIRATIONEN ANSEHEN →`

2. `02 Stil & Ideen festlegen`  
   Text: `Wir verstehen Ihre Wünsche und Ihren Stil.`  
   Link: `MEHR ERFAHREN →`

3. `03 Planung & Umsetzung`  
   Text: `Ihre Küche. Perfekt geplant. Perfekt umgesetzt.`  
   Link: `BERATUNG STARTEN →`

Animation:

- Die drei Karten fahren beim Scrollen leicht gegeneinander versetzt rein:
  - Karte 1: von links unten, rotate `-2deg` → `0deg`
  - Karte 2: von unten, scale `0.94` → `1`
  - Karte 3: von rechts unten, rotate `2deg` → `0deg`
- Hover: Karte hebt sich, Bild zoomt leicht, Zahl bekommt Gold-Glow.

---

## Section B – Exploding Kitchen / Technik-Highlight

Das ist die wichtigste Signature-Section. Sie darf nicht klein wirken.

Layout:

- Heller Section-Hintergrund.
- Links großer Textblock.
- Mitte/rechts riesige Exploded-Kitchen-Grafik/Bild, mindestens 55–60% Breite.
- Rechts daneben technische Callout-Liste mit feinen Linien zur Grafik.
- Kleine Video-/360°-Kachel unten links unter dem Text.

Headline links:

```text
Technik, die man
nicht sieht. Qualität,
die man spürt.
```

Text:

```text
Unsere Küchen entstehen mit höchster Präzision – bis ins Detail durchdacht und perfekt aufeinander abgestimmt.
```

Mini-Bullets:

```text
Millimetergenaue Planung
Perfekte Funktionalität
Langlebige Materialien
```

Button/Link:

```text
SO ENTSTEHT IHRE KÜCHE →
```

Callouts rechts:

```text
01 ARBEITSPLATTE
Sorgfältig ausgewählt. Perfekt verarbeitet.

02 TECHNIK & FUNKTION
Intelligent integriert. Unsichtbar effizient.

03 KORPUS & STAURAUM
Maximale Organisation. Höchste Stabilität.

04 LICHT & ATMOSPHÄRE
Stimmung durch Licht. In Szene gesetzt.
```

Animation:

- Diese Section soll als „Sticky Highlight“ wirken.
- Wenn technisch machbar: Section für ca. `140vh` pinnen/sticky machen.
- Exploded-Kitchen-Bild startet leicht zusammengedrückt und fährt beim Scroll in Layer auseinander:
  - Falls Bild nur ein statisches PNG ist: simuliere Bewegung mit `scale`, `translateY`, `filter`, Callout-Reveals und Goldlinien.
  - Wenn einzelne Layer existieren: Arbeitsplatte, Korpus, Auszüge, Lichtlayer getrennt animieren.
- Callouts erscheinen nacheinander von oben nach unten.
- Goldene Linien zeichnen sich per CSS `scaleX(0 → 1)` ein.
- Kleines `360° ANSICHT`-Thumbnail bekommt Play-Button-Pulse.

Wichtig: Diese Section muss größer und dominanter sein als aktuell. Nicht wie ein normales Bildchen behandeln.

---

## Section C – „Warum eine Küche von VIDEKO?“

Layout wie Referenz:

- Links Headline.
- Rechts eine Reihe kleiner Premium-Feature-Cards.
- Letzte Card ist etwas größer/highlighted mit Goldrand und CTA.
- Die Cards dürfen leicht versetzt stehen.

Headline:

```text
Warum eine Küche
von VIDEKO?
```

Cards:

1. `Echte Manufaktur`  
   `Keine Massenware. Individuell für Sie gefertigt.`

2. `Premium Materialien`  
   `Nur das Beste für Langlebigkeit & Ästhetik.`

3. `Individuelles Design`  
   `Ihre Persönlichkeit spiegelt sich in jeder Linie.`

4. `Persönliche Betreuung`  
   `Von der ersten Idee bis zur perfekten Umsetzung.`

5. Highlight Card:  
   `Erleben Sie den VIDEKO Unterschied.`  
   Button: `MEHR ERFAHREN →`

Animation:

- Cards kommen gestaffelt von unten.
- Beim Hover Icon-Gold-Glow und Card-Shadow.
- Highlight-Card hat dauerhaft sehr dezentes Pulsieren der Goldkante.

---

## Section D – Stylefinder als digitales Produkt

Diese Section muss aussehen wie ein premium digitales Feature, nicht wie eine normale Karte.

Layout:

- Links großer Textblock auf heller großer Card.
- Mitte ein dunkles Smartphone-/Tablet-Mockup mit Stylefinder UI.
- Rechts 3 Style-Karten horizontal, mit Pfeil-Button rechts.
- Dezente goldene Light-Trails im Hintergrund.

Text links:

```text
STYLEFINDER

Finden Sie Ihren Stil.
In Sekunden.

Beantworten Sie 5 kurze Fragen und entdecken Sie Küchen, die perfekt zu Ihnen passen.
```

Button:

```text
STIL FINDEN →
```

Stylefinder UI im Device:

```text
02 / 05
Welche Atmosphäre begeistert Sie?

Warm & natürlich
Klar & modern
Dunkel & elegant

WEITER →
```

Style-Cards rechts:

1. `Modern Luxury`  
   `Reduziert. Klar. Zeitlos.`

2. `Natural Essence`  
   `Warm. Authentisch. Natürlich.`

3. `Dark Elegance`  
   `Dramatisch. Edel. Ausdrucksstark.`

Animation:

- Device fährt leicht von unten rein und kippt minimal in Position.
- Style-Karten swipen beim Scroll leicht horizontal ein.
- Option im Device leuchtet nacheinander auf.
- Kleine Materialchips schweben langsam (`floating animation`, 6–8 Sekunden loop).

---

## Section E – VIDEKO Studios / Erlebniswelt

Layout wie Referenz:

- Links Textblock.
- Rechts horizontale Gallery/Carousel mit 5 Karten.
- Mittlere Karte größer und hervorgehoben.
- Runde Pfeile links/rechts.

Headline:

```text
VIDEKO Studios

Erleben. Anfassen.
Inspirieren lassen.
```

Text:

```text
Tauchen Sie ein in unsere Erlebniswelt und lassen Sie sich inspirieren.
```

Button:

```text
STANDORT FINDEN →
```

Kartenlabels:

- `Studio München`
- `Studio Hamburg`
- `Studio Düsseldorf` – Highlight Card
- `Studio Stuttgart`
- `Studio Berlin`

Wichtig: Für VIDEKO später bitte echte Standortdaten einsetzen. Wenn bisher nur Würzburg existiert, nenne die Karten alternativ:

- `Materialwelt`
- `Beratungslounge`
- `Küchenkoje Modern`
- `Küchenkoje Natur`
- `Technikbereich`

Animation:

- Gallery bekommt horizontalen Drag/Swipe-Effekt oder zumindest Pfeilnavigation.
- Beim Scroll bewegen sich Karten leicht unterschiedlich schnell für Parallax.
- Mittlere Karte bekommt stärkeren Schatten und Goldkante.

---

## Section F – Vorher/Nachher Transformation

Layout:

- Links Textblock.
- Rechts breiter Before/After-Slider.
- Rechts daneben kleine Zahlen/Stats.

Headline:

```text
Aus Ideen werden
Meisterwerke.
```

Text:

```text
Sehen Sie beeindruckende Verwandlungen, die unsere Küchen möglich machen.
```

Link:

```text
MEHR VERWANDLUNGEN →
```

Stats:

```text
+87% mehr Stauraum
+3 Lichtzonen
100% zufriedene Kunden
```

Animation / Funktion:

- Echter Before/After-Slider, wenn möglich per Drag.
- Alternativ: CSS-Slider mit Mousemove/Range Input.
- Beim Scroll soll der Slider automatisch kurz von 40% auf 58% fahren, damit Bewegung sichtbar ist.
- Slider-Griff pulsiert leicht.

---

## Section G – Prozess: „Ihr Weg zu Ihrer VIDEKO Küche.“

Layout:

- Links Headline.
- Rechts eine horizontale Timeline mit 6 runden Bild-/Icon-Steps.
- Goldene Linie verbindet die Schritte.
- Steps sind nicht als langweilige Boxen, sondern als runde/organische Punkte mit kurzem Text darunter.

Headline:

```text
Ihr Weg zu Ihrer
VIDEKO Küche.
```

Steps:

1. `Beratung` – `Kennenlernen & Verstehen Ihrer Wünsche.`
2. `Planung` – `Individuelles Design & millimetergenaue Planung.`
3. `Bemusterung` – `Materialien & Details für Ihre perfekte Küche.`
4. `Fertigung` – `Mit Präzision gefertigt.`
5. `Montage` – `Perfekt montiert und bis ins Detail abgestimmt.`
6. `Genießen` – `Ihre Küche. Für viele Jahre Freude.`

Animation:

- Goldene Linie zeichnet sich beim Scroll von links nach rechts.
- Steps poppen nacheinander auf.
- Aktiver Step bekommt Gold-Glow.

---

## Section H – Team

Layout:

- Links Textblock.
- Rechts 4 große Portrait-Cards.
- Cards haben dunkle Bildflächen, aber die Section bleibt hell.
- Rechts runder Pfeil für Carousel-Gefühl.

Headline:

```text
Menschen mit
Leidenschaft für
Küchenkultur.
```

Text:

```text
Unser Team aus Designern, Planern und Handwerkern vereint Expertise, Kreativität und Perfektionismus.
```

CTA:

```text
MEET THE TEAM →
```

Portrait-Namen als Platzhalter, falls echte Teamdaten fehlen:

- `Maximilian Voss – Geschäftsführung`
- `Julia Huber – Design Leitung`
- `Stefan Krug – Planung & Beratung`
- `Melanie Bauer – Innenarchitektur`

Animation:

- Cards kommen als Carousel-Reveal von rechts.
- Hover: Portrait zoomt leicht, Name-Overlay fährt minimal hoch.

---

## Section I – Inspiration & Journal

Layout:

- Links Textblock.
- Rechts 4 Artikelkarten in einer Reihe.
- Nicht zu groß, aber sauber und hochwertig.

Headline:

```text
Inspiration & Journal

Ideen, Trends und Geschichten rund um das Thema Küche.
```

CTA:

```text
ZUM JOURNAL →
```

Cards:

1. `Küchentrends 2026`  
   `Das kommt, bleibt und begeistert.`

2. `Naturstein in der Küche`  
   `Zeitlose Eleganz mit Charakter.`

3. `Die perfekte Kücheninsel`  
   `Funktion trifft auf Design.`

4. `Einblick in unsere Manufaktur`  
   `So entsteht Ihre Küche.`

Animation:

- Artikelkarten bekommen Hover-Image-Zoom.
- Beim Scroll leicht versetzt einblenden.

---

# 4. Übergang zum dunklen Abschluss

Der letzte helle Abschnitt muss sauber in den bestehenden dunklen CTA/Footer übergehen.

Optional: vor dem dunklen Abschluss eine leichte Wave/Diagonal-Transition wie im Referenzbild.

Der dunkle Abschluss soll nicht durch hellen Content ersetzt werden. Bitte bestehen lassen oder nur minimal angleichen.

---

# 5. Was ausdrücklich NICHT passieren darf

- Nicht wieder eine normale Standard-Grid-Website bauen.
- Nicht alle Sections mittig und gleich groß machen.
- Nicht die Inhalte winzig auf riesiger beiger Fläche platzieren.
- Nicht nur Fade-In verwenden und behaupten, das seien Animationen.
- Nicht Hero und Footer komplett umbauen.
- Nicht den weißen Mittelteil statisch lassen.
- Nicht dunkle Zwischenbanner im Mittelteil einbauen. Kleine dunkle Cards sind okay, aber der Gesamtbereich muss hell bleiben.
- Keine überladenen Textwüsten.

---

# 6. Technische Umsetzungsvorgaben

Bitte zuerst die bestehende Landingpage-Komponente finden. Dann:

1. Hero oben identifizieren und möglichst unverändert lassen.
2. Den bestehenden weißen Mittelteil entfernen/ersetzen.
3. Neue Komponenten für die Sections A–I erstellen.
4. Bestehenden dunklen Abschluss/Footer beibehalten.
5. Responsiveness prüfen.
6. Animationen sauber integrieren.
7. Performance beachten: Bilder lazy-loaden, außer oberhalb des Folds.
8. Keine externen Bild-URLs verwenden, wenn lokale Assets vorhanden sind.
9. Wenn keine passenden Bilder vorhanden sind, mit Platzhalter-Assets arbeiten, aber Klassen und Struktur sauber vorbereiten.

---

# 7. Vorschlag für Komponentenstruktur

Falls React/Next/Vite genutzt wird:

```text
LandingPage
  HeroCurrent                     // bestehen lassen
  HomeExperienceMiddle            // neu
    StartPathsSection
    ExplodingKitchenSection
    VidekoDifferenceSection
    StylefinderShowcaseSection
    StudioExperienceSection
    BeforeAfterSection
    ProcessTimelineSection
    TeamSection
    JournalPreviewSection
  FinalCtaAndFooterCurrent        // bestehen lassen
```

Hilfskomponenten:

```text
Reveal
ParallaxImage
GoldButton
FeatureCard
ImageCard
SectionLabel
BeforeAfterSlider
ScrollTimeline
```

---

# 8. CSS-Klassen / Animationen grob

Nutze sprechende Klassen, z. B.:

```css
.home-middle {
  background:
    radial-gradient(circle at 15% 10%, rgba(216,194,139,.22), transparent 28%),
    radial-gradient(circle at 80% 35%, rgba(255,255,255,.7), transparent 32%),
    linear-gradient(180deg, #fbf7ee 0%, #f6f1e8 100%);
  color: #16130f;
  position: relative;
  overflow: hidden;
}

.home-middle::before {
  content: "";
  position: absolute;
  inset: 0;
  pointer-events: none;
  opacity: .45;
  background-image: url('/textures/subtle-paper.png');
  mix-blend-mode: multiply;
}

.gold-line {
  height: 1px;
  background: linear-gradient(90deg, transparent, rgba(184,149,79,.65), transparent);
  transform-origin: left;
}
```

Für Cards:

```css
.premium-card {
  position: relative;
  overflow: hidden;
  border: 1px solid rgba(120,95,45,.16);
  border-radius: 20px;
  background: rgba(255,255,255,.72);
  box-shadow: 0 24px 70px rgba(45,35,20,.10);
  transition: transform .45s cubic-bezier(.22,1,.36,1), box-shadow .45s;
}

.premium-card:hover {
  transform: translateY(-8px);
  box-shadow: 0 32px 90px rgba(45,35,20,.18);
}
```

---

# 9. Qualitätskontrolle nach Umsetzung

Am Ende bitte prüfen:

- Ist der Hero oben noch dunkel und wie vorher?
- Ist der gesamte Mittelteil hell?
- Ist der Footer/CTA unten dunkel?
- Wirkt die Exploding-Kitchen-Section wie der zentrale Wow-Moment?
- Gibt es echte Scroll-/Hover-/Swipe-/Slider-Effekte?
- Sind die Sections abwechslungsreich und nicht wie normale Kacheln?
- Sieht die Seite auf Desktop wirklich wie die Referenz aus?
- Funktioniert Mobile ohne Layoutbruch?

Bitte gib danach kurz aus:

```text
Geändert:
- ...
Animationen:
- ...
Noch Platzhalter:
- ...
```
