VIDEKO Landingpage Claude Pack

Inhalt:
- CLAUDE_PROMPT.md: Hauptprompt für Claude
- assets/reference_white_middle_target.png: Referenzbild, an dem der weiße Mittelteil orientiert werden soll
- docs/SECTION_BLUEPRINT.md: Kurzstruktur der Sections
- docs/ANIMATION_CHECKLIST.md: Pflichtliste für Effekte/Animationen

Anwendung:
1. Zip entpacken.
2. Referenzbild und CLAUDE_PROMPT.md in Claude hochladen.
3. Claude am bestehenden Projekt arbeiten lassen.
4. Wichtig: Hero oben und Footer unten sollen bleiben; nur der weiße Mittelteil wird ersetzt.
