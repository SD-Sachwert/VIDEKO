# Checkliste für Claude

- [ ] Alter Kartenblock komplett ersetzt
- [ ] Keine Filterchips mehr
- [ ] Keine Karten im Hintergrund sichtbar
- [ ] Nur eine aktive Rolle gleichzeitig sichtbar
- [ ] 6 neue Karten aus dem Ordner `karten` eingebaut
- [ ] Rollenreihenfolge korrekt
- [ ] Sticky Scroll oder Klick-Wechsel umgesetzt
- [ ] Saubere Active States
- [ ] Marble-Gold-Hintergrund passend zur Website
- [ ] Mobile sauber gelöst
- [ ] Microcopy-Leiste unter dem Block eingebaut
