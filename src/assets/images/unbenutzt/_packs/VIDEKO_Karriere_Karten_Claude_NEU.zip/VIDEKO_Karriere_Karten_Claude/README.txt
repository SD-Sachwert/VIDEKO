Inhalt dieser ZIP:

- 00_CLAUDE_PROMPT_KARRIERE_SCROLLBLOCK.txt
  Kompletter Prompt für Claude zum Austausch des Karriere-Kartenblocks.

- 01_CHECKLISTE.md
  Kurzcheck, ob der Block sauber umgesetzt wurde.

- ordner karten/
  Die 6 finalen Jobkarten als eigenständige Bilder.

- ordner referenz/
  Ein Mockup-Bild, das die gewünschte Richtung des Scroll-Showcase-Blocks zeigt.
