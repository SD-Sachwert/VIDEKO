# VIDEKO Claude Masterprompt – Runde 4

Inhalt dieser ZIP:
- `00_CLAUDE_MASTERPROMPT.txt`
- `01_CHECKLISTE.md`
- `screenshots/` mit Referenzbildern

Ziel:
Gezielte Überarbeitung mehrerer konkreter Sektionen der VIDEKO-Website.
Kein Komplett-Redesign, sondern präziser Feinschliff an Slider, Regionalbereich, Divider-System und Prozessblock.
