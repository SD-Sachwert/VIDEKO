# VIDEKO – Checkliste für Claude (Runde 4)

## 1. Slider-Bereich
- [ ] 15–20 weiße Post-its / Infobausteine rund um das Bild platziert
- [ ] Post-its leicht wild / natürlich / schräg verteilt
- [ ] Inhalte zeigen klar, was VIDEKO alles leistet
- [ ] Bereich wirkt hochwertig statt chaotisch

## 2. Regional-/Standortbereich
- [ ] Rechte Karte ohne Textblock
- [ ] Linke Textspalte und rechte Karte gleich groß / gleich hoch
- [ ] Orts-Chips entfernt
- [ ] Stattdessen mehr Fließtext links eingebaut

## 3. Goldener Divider
- [ ] Lange Divider-Version entfernt
- [ ] Nur noch kurze goldene Divider-Version im Einsatz
- [ ] Divider zwischen Sektionen auf allen Unterseiten eingebaut
- [ ] Länge/Farbe/Stärke/Abstände global einheitlich

## 4. Prozessblock
- [ ] Linker, mittlerer und rechter Bereich wirken höhengleich
- [ ] Mittelspalte mit Prozesspunkten etwas länger gemacht
- [ ] Gesamter Block wirkt ausbalanciert und zusammengehörig

## Global
- [ ] Mobile / Tablet / Desktop geprüft
- [ ] Keine Layoutbrüche
- [ ] Keine übergroßen Leerflächen
- [ ] VIDEKO-Look bleibt erhalten
