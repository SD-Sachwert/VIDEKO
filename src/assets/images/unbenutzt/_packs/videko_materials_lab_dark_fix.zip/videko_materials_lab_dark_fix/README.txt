VIDEKO Materials Lab – Dark Fix Package

Enthalten:
- 00_aktueller_stand_materials_lab.png: Screenshot der aktuellen, zu hellen Umsetzung
- CLAUDE_PROMPT_MATERIALS_LAB_DARK_FIX.txt: fertiger Korrektur-Prompt für Claude

Ziel:
Claude soll NUR die zusätzliche Materials-Lab-Sektion ganz unten auf der Inspirationsseite überarbeiten.
Die Sektion soll dunkel, luxuriös und kontrastreicher werden.
