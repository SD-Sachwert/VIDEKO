VIDEKO JOURNAL – KOMPLETTPAKET

Inhalt:
- 01_MASTER_PROMPT_CLAUDE_JOURNAL.txt
  Der zentrale Prompt für Claude, damit die komplette Journal-Seite gebaut wird.
- 02_ARTIKELTEXTE_JOURNAL.txt
  Ausformulierte Artikeltexte für die Artikelseiten.
- 03_FAQ_UND_MYTHEN_CONTENT.txt
  Fertige Fragen, Antworten und Mythos-Inhalte für die zusätzlichen Bausteine.
- 04_SEITENSTRUKTUR_PLATZIERUNG.txt
  Klare Reihenfolge der Sektionen und Hinweise zur Platzierung.
- assets/
  Referenzbilder für das gewünschte Layout und die drei zusätzlichen Bausteine.

Empfohlene Nutzung:
1. Zuerst 01_MASTER_PROMPT_CLAUDE_JOURNAL.txt komplett in Claude einfügen.
2. Danach 02_ARTIKELTEXTE_JOURNAL.txt und 03_FAQ_UND_MYTHEN_CONTENT.txt mitgeben.
3. Referenzbilder aus assets/ anhängen, damit Claude die Optik sauber versteht.
4. 04_SEITENSTRUKTUR_PLATZIERUNG.txt nutzen, falls Claude die Reihenfolge nicht sauber trifft.

Wichtig:
- Stil durchgehend VIDEKO: oben dunkler Hero, mittig heller Contentbereich, unten dunkler CTA/Footer.
- Keine Platzhalter, keine leeren Karten, kein Lorem Ipsum.
- Animationen dezent, hochwertig, nicht übertrieben.
