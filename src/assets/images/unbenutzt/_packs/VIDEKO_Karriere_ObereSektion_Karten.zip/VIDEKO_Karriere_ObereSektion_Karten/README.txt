Inhalt der ZIP:

- 00_CLAUDE_PROMPT_OBERE_KARRIERESEKTION.txt
  Vollständiger Prompt für Claude zum Einbau der neuen oberen Karriere-Sektion.

- 01_CHECKLISTE.md
  Kurzcheck für die saubere Umsetzung.

- ordner karten/
  Die 6 finalen Benefit-/Philosophie-Karten im VIDEKO-Stil.

- ordner referenz/
  Das Referenzbild, an dessen Wirkung und Aufbau sich die Sektion orientieren soll.
