# Checkliste für Claude

- [ ] Obere helle Sektion auf der Karriere-Seite ersetzt
- [ ] Referenzbild als gestalterische Richtung berücksichtigt
- [ ] 6 Karten aus dem Ordner `karten` eingebaut
- [ ] Keine langweilige Benefit-Grid-Struktur
- [ ] Kartenbühne / Carousel-Look mit Fokuskarte umgesetzt
- [ ] Linke Textspalte mit Headline + Einleitung sauber gesetzt
- [ ] Feine goldene Linien / hochwertige Motion / Tiefenwirkung integriert
- [ ] Dots / Progress oder sanfte Navigation eingebaut
- [ ] Mobile als Swipe-/Snap-Lösung sauber umgesetzt
- [ ] Korrigierte Karte 03 ohne falsches Logo verwendet
