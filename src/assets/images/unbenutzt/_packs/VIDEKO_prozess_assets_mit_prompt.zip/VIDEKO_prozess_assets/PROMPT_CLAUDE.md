# Prompt für Claude – VIDEKO Prozesssektion einbauen

Baue auf der Landingpage eine neue hochwertige **„Unser Prozess“**-Sektion ein – optisch und strukturell **so nah wie möglich an der Referenz `00_reference_mockup_prozesssektion.png`**. 

## Wichtige Regel
- **Nichts anderes auf der Seite löschen oder zerstören.**
- Die neue Sektion nur sauber ergänzen bzw. die alte langweilige Prozesssektion ersetzen.
- Die Sektion soll **responsiv**, **sauber aufgebaut** und **visuell stark** sein.

## Ziel
Die aktuelle Prozesssektion wirkt zu statisch. Die neue Version soll deutlich wertiger, emotionaler und moderner wirken – mit einer eleganten goldenen Linie als visuelle Führung, schwebenden Karten, weichen Schatten, hochwertigen Bildausschnitten und klarer Hierarchie.

## Inhalt / Headline
Eyebrow:
**UNSER PROZESS**

Headline zweizeilig:
**So entsteht aus deinem Raum**
**dein Lieblingsort.**

Dabei soll **„dein Lieblingsort.“** in Gold bzw. warmem Goldton hervorgehoben werden, der Rest in dunklem Text.

## Stil / Look
- Heller, warmer cremefarbener Hintergrund
- Sehr subtile Stein-/Marmorstruktur im Hintergrund
- Hochwertige Serifenschrift für die große Headline
- Saubere Sans-Serif für Labels und Fließtext
- Goldene Akzente, aber nicht kitschig
- Sehr weiche Schatten
- Große Luftigkeit / viel Weißraum
- Premium-Webdesign, kein Baukasten-Look

## Aufbau
- Zentral oben die Headline
- Darunter eine **fließende goldene Linie / Wellenlinie** als visueller Pfad durch alle 6 Schritte
- An dieser Linie sitzen 6 Karten/Steps versetzt entlang der Kurve
- Jede Karte ist eine helle, leicht schwebende Card mit großem Radius, softem Shadow und klarer Typohierarchie
- Kleine Icon-Badges oben in den Karten
- Zwischen den Steps darf die Linie elegant mit goldenen Knotenpunkten / kleinen Kugeln verlaufen
- Unten mittig kann ein dezentes VIDEKO-Branding wie in der Referenz stehen

## Steps – Text exakt so verwenden

### 01
**KENNENLERNEN**  
Wir lernen dich und deinen Raum kennen.

### 02
**BERATUNG**  
Ehrlich, persönlich, ohne Druck.

### 03
**PLANUNG IN 3D / VR**  
Du siehst dein Ergebnis vorab.

### 04
**DETAILS & MATERIALIEN**  
Wir feilen, bis alles passt.

### 05
**KOORDINATION & UMBAU**  
Wir steuern Gewerke und Montage.

### 06
**FERTIGES ERGEBNIS**  
Dein neuer Raum – zum Verlieben.

## Bildzuordnung
Verwende die mitgelieferten Bilder gezielt in den Karten bzw. als kleine ergänzende Visuals:

- `03_skizze_planung.png`
  - Als kleines Begleitvisual bei Step 01 oder unten links als dekoratives Einführungsbild.
- `04_beratung_materialmoodboard.png`
  - Für Step 02 „Beratung“.
- `05_3d_vr_render.png`
  - Für Step 03 „Planung in 3D / VR“.
- `06_details_materialien.png`
  - Für Step 04 „Details & Materialien“.
- `07_koordination_umbau.png`
  - Für Step 05 „Koordination & Umbau“.
- `01_vorher_raum.png` + `02_fertiger_raum.png`
  - Für Step 06 als **Before/After-Slider** oder als gesplittetes Vorher/Nachher-Visual.

## Funktionswunsch für Step 06
- Zeige einen kleinen Before/After-Slider oder ein Split-Visual
- Linke Seite = `01_vorher_raum.png`
- Rechte Seite = `02_fertiger_raum.png`
- Wenn ein echter Slider zu aufwendig ist, baue wenigstens eine klare Split-Ansicht mit einem runden Handle in der Mitte, damit es wie ein Slider wirkt

## Animation / Interaktion
Bitte dezent, hochwertig und performant:
- Cards leicht nach oben schweben bei Hover
- Schatten bei Hover etwas stärker
- Goldlinie / Knotenpunkte dürfen mit sanftem Entrance erscheinen
- Bilder in den Cards dürfen leicht reinfaden
- Kein wildes Geblinke, keine billigen Effekte

## Responsives Verhalten
- Desktop: großer inszenierter Verlauf wie in der Referenz
- Tablet: Steps ordentlich umbrechen, Linie darf vereinfacht werden
- Mobile: vertikaler Flow / Timeline erlaubt, aber weiterhin hochwertig und sauber
- Wichtig: Lesbarkeit und gute Abstände priorisieren

## Technische Anforderungen
- Saubere Struktur und Klassen
- Bestehendes Designsystem möglichst nutzen, aber visuell nah an der Referenz bleiben
- Bilder optimiert einbauen
- Keine Layout-Sprünge
- Keine vorhandenen globalen Styles kaputtmachen

## Was ich am Ende will
Ich will eine Sektion, die beim Scrollen direkt sagt: **Das ist hochwertig, durchdacht und nicht generisch.**
Sie soll fast wie eine kleine Marken-Inszenierung wirken – nicht wie eine stinknormale 6-Spalten-Prozessliste.
