# Asset-Map – VIDEKO Prozesssektion

## Dateien und Einsatz
- `00_reference_mockup_prozesssektion.png`
  - Gesamtreferenz für Layout, Stimmung, Typografie, Abstände und Aufbau.
- `01_vorher_raum.png`
  - Für Step 06 als linke Hälfte im Before/After-Slider.
- `02_fertiger_raum.png`
  - Für Step 06 als rechte Hälfte im Before/After-Slider.
- `03_skizze_planung.png`
  - Dekoelement unter/bei Step 01 oder als kleines begleitendes Visual für den Einstieg.
- `04_beratung_materialmoodboard.png`
  - Bild für Step 02 „Beratung“.
- `05_3d_vr_render.png`
  - Bild für Step 03 „Planung in 3D / VR“.
- `06_details_materialien.png`
  - Bild für Step 04 „Details & Materialien“.
- `07_koordination_umbau.png`
  - Bild für Step 05 „Koordination & Umbau“.

## Reihenfolge der Steps
1. Kennenlernen
2. Beratung
3. Planung in 3D / VR
4. Details & Materialien
5. Koordination & Umbau
6. Fertiges Ergebnis
