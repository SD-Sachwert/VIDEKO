# Claude Prompt – neue Stylefinder-Sektion zusätzlich auf Landingpage einbauen

Bitte baue **eine neue zusätzliche Sektion** auf der Landingpage ein, die sich an der beigefügten Referenz orientiert.

## Ganz wichtig
- **Nichts löschen.**
- **Keine bestehenden Sektionen entfernen oder umbauen.**
- Diese neue Sektion soll **nur zusätzlich** eingebaut werden.
- Platziere sie **ganz oben auf der Landingpage als erste Content-Sektion direkt nach dem bestehenden Hero / Banner**, damit ich sie mir sofort anschauen kann.
- Ziel ist erstmal ein sauberer visueller und funktionaler Einbau zum Testen.

## Ziel der Sektion
Die Sektion soll Besucher klar in den **Stylefinder** ziehen. Der Stylefinder ist das Hauptziel und muss deutlich dominanter sein als die beiden flankierenden Karten.

## Visuelle Referenz
Nutze `assets/00_layout_reference_stylefinder_section.png` als visuelle Leitidee für:
- Größenverhältnisse
- Hierarchie
- Grundlayout
- Stilrichtung
- Premium-Anmutung

Bitte **nicht pixelgenau kopieren**, aber die Richtung und Wirkung sollen sehr nah dran sein.

## Inhaltliche Struktur
### Headline-Bereich
Kleine Eyebrow:
- „DEIN WEG ZUR TRAUMKÜCHE“

Hauptheadline:
- „Starte mit dem Stylefinder.“

Subline:
- „In nur 2 Minuten zu deinem perfekten Küchenstil.“
- „Einfach, kostenlos und unverbindlich.“

## Kartenaufbau
Es gibt drei Hauptkarten in einer Reihe:

### 1. Linke Karte – Inspiration finden
Verwende `assets/01_inspiration_side_card.png`

Inhalt:
- Titel: „Inspiration finden“
- Text: „Entdecke Stile, Materialien und Ideen für Küchen, die zu dir passen.“
- CTA: „Ideen ansehen“

### 2. Mittlere Hauptkarte – Stylefinder starten
Diese Karte ist standardmäßig **aktiv und größer** als die beiden seitlichen Karten.

Inhalt:
- kleines Label oben: „EMPFOHLENER ERSTER SCHRITT“
- Titel: „Stylefinder starten“
- Text: „Beantworte 7 kurze Fragen und erhalte deinen persönlichen Küchenstil mit 92% Match.“

#### Quiz-Preview innerhalb der Karte
Zeige eine Preview mit:
- Fortschritt: „Frage 1 von 7“
- Frage: „Welche Atmosphäre spricht dich am meisten an?“
- vier Optionen mit den folgenden Bildern:
  - `assets/02_style_option_modern_luxury.png` → „Modern Luxury“
  - `assets/03_style_option_warm_natural.png` → „Warm Natural“
  - `assets/04_style_option_purist_minimal.png` → „Purist Minimal“
  - `assets/05_style_option_classic_elegant.png` → „Classic Elegant“
- „Modern Luxury“ soll standardmäßig als ausgewählt markiert sein.

#### Ergebnis-Vorschau
Zeige darunter eine kompakte Ergebniszeile mit:
- kleinem Bild `assets/07_stylefinder_result_preview.png`
- Text:
  - „Voraussichtliches Ergebnis“
  - „Modern Luxury – 92% Match“
  - „Zeitlos. Edel. Individuell.“
- rechts ein kleines rundes Badge mit „92% Match“

#### Haupt-CTA der mittleren Karte
- Button: „JETZT STYLEFINDER STARTEN“

#### Microcopy darunter
- „Kostenlos“
- „ca. 2 Minuten“
- „Ohne Registrierung“

### 3. Rechte Karte – Persönliche Beratung
Verwende `assets/06_persoenliche_beratung_side_card.png`

Inhalt:
- Titel: „Persönliche Beratung“
- Text: „Gemeinsam planen wir deine Traumküche – ehrlich, persönlich und auf Augenhöhe.“
- CTA: „Beratung anfragen“

## Interaktion / Verhalten
Das ist sehr wichtig:
- Die drei Karten sollen **interaktiv** sein.
- Standardmäßig ist die **mittlere Stylefinder-Karte aktiv und größer**.
- Wenn ich auf die linke oder rechte Karte klicke, soll die gewählte Karte **in den Fokus / in die aktive große Position wechseln**.
- Die zuvor aktive Karte soll kleiner werden und an die Seite rücken.
- Also genau dieser Effekt: **links/rechts anwählen = wird groß / aktiv**.
- Nur eine Karte ist gleichzeitig aktiv.
- Die Übergänge sollen weich und hochwertig wirken.

## Technische Erwartung für Interaktion
- Nutze eine saubere state-basierte Lösung.
- Idealerweise als kleines Carousel / Slider-artiges Drei-Karten-System.
- Sanfte Animationen für `transform`, `opacity`, `scale`, `shadow`.
- Kein Hacky-Gefrickel.
- Desktop: klare Dreierdarstellung.
- Mobile: sauber responsiv, notfalls untereinander oder horizontal swipebar.

## Styling / Look
Die Sektion soll:
- hochwertig
- modern
- warm
- premium
- clean
- conversion-stark
wirken.

Gewünschte Stilmittel:
- helle luxuriöse Fläche
- goldene Akzente
- elegante Typografie
- weiche Schatten
- runde Ecken
- ruhige Premium-UI

## Trust-/Benefit-Leiste unterhalb der Karten
Bitte unter der Kartenreihe zusätzlich eine schmale Benefit-Leiste einbauen mit vier Punkten:
1. „100% unverbindlich“ / „Ohne Verpflichtungen“
2. „Für deinen Stil“ / „Individuell & persönlich“
3. „2 Minuten Zeit“ / „Schnell & unkompliziert“
4. „Expertenqualität“ / „Über 20 Jahre Erfahrung“

Die darf dezent sein und muss nicht mit externen Grafiken gebaut werden.

## Ganz wichtig zum Einbau
- Diese Sektion **nur zusätzlich auf die Landingpage setzen**.
- **Noch nichts anderes ersetzen oder löschen.**
- Bestehende Sektionen unverändert lassen.
- Es geht jetzt erstmal darum, diese neue Sektion oben einzubauen, damit ich sie live sehe und testen kann.

## Wenn Ziel-Links noch nicht final sind
Dann vorerst Platzhalter / bestehende Routen verwenden, aber die CTA-Buttons sauber anklickbar machen.

## Ergebnis
Am Ende soll die Landingpage oben direkt diese neue Stylefinder-Sektion zusätzlich zeigen, ohne dass bestehende Inhalte verloren gehen.
