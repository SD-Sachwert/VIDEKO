# Asset-Mapping für die Stylefinder-Sektion

## Referenz / Zielbild
- `assets/00_layout_reference_stylefinder_section.png`
  - visuelle Zielrichtung für Aufbau, Größenverhältnisse und Gesamtwirkung

## Seitliche Karten
- `assets/01_inspiration_side_card.png`
  - Bild für die linke Karte „Inspiration finden“
- `assets/06_persoenliche_beratung_side_card.png`
  - Bild für die rechte Karte „Persönliche Beratung“

## Stylefinder-Preview in der mittleren Karte
- `assets/02_style_option_modern_luxury.png`
  - Option „Modern Luxury“
- `assets/03_style_option_warm_natural.png`
  - Option „Warm Natural“
- `assets/04_style_option_purist_minimal.png`
  - Option „Purist Minimal“
- `assets/05_style_option_classic_elegant.png`
  - Option „Classic Elegant“
- `assets/07_stylefinder_result_preview.png`
  - kleines Ergebnis-/Preview-Bild in der Result-Zeile
