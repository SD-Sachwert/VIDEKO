# Technische Anweisung für Claude / Entwickler

## Einbau-Ort
- Neue Sektion direkt **unter dem bestehenden Hero/Banner** als erste Content-Sektion der Landingpage einfügen.
- Keine bestehende Sektion löschen, verschieben oder überschreiben.
- Wenn nötig, die neue Sektion hinter einem Feature-Flag oder klar isolierten Component-Block ergänzen.

## Komponentenidee
Empfohlen:
- `LandingStylefinderSection`
- `StylefinderCardCarousel`
- `StylefinderPreview`
- `SideInfoCard`
- `BenefitStrip`

## State-Logik
Ein aktiver Zustand für die drei Hauptkarten:
- `activeCard = 'stylefinder' | 'inspiration' | 'beratung'`
- Default: `stylefinder`

Verhalten:
- Klick auf linke/rechte Karte setzt `activeCard`
- aktive Karte wird größer, bekommt stärkeren Schatten, höhere Priorität, evtl. minimalen Lift
- inaktive Karten werden kleiner und zurückgenommen

## Layout Desktop
- 3 Karten in einer Reihe
- mittlere Karte größer
- linke/rechte Karten schmaler
- genug Abstand, damit der aktive Fokus klar lesbar bleibt

## Layout Mobile
- bevorzugt swipebar oder untereinander stapelbar
- Lesbarkeit und CTA-Klickbarkeit priorisieren

## Animationen
Empfohlen:
- `transition: transform 350ms ease, opacity 350ms ease, box-shadow 350ms ease, filter 350ms ease;`
- aktive Karte via `scale(1)` bis `scale(1.02)`
- inaktive Karten leicht reduziert
- kein hartes Springen

## Asset-Nutzung
Siehe `README_ASSET_MAPPING.md`

## Muss-Anforderungen
- bestehende Landingpage bleibt intakt
- neue Sektion nur zusätzlich
- Referenzbild dient als Look-and-Feel-Vorlage
- CTA-Buttons klickbar
- Stylefinder mittig und dominant
- linke/rechte Karte per Klick aktivierbar

## Nice-to-have
- Hover-Feedback auf Karten
- sanfter Parallax-/Lift-Effekt bei Hover
- kleine Icon-Badges oben in den Seitencards, falls passend
