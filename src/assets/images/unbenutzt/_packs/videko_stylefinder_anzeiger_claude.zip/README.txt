Inhalt:
- referenz_stylefinder_anzeiger_neu.png
- claude_prompt_stylefinder_anzeiger.txt

Ziel:
Claude soll den Stylefinder-Fortschrittsanzeiger ersetzen:
weg vom einfachen Kreis, hin zu einer edlen offenen 7-Schritte-Anzeige mit besser sichtbarem VIDEKO-Logo.
