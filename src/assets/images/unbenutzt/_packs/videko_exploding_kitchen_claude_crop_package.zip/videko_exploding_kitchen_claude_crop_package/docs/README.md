# VIDEKO Exploding Kitchen – Claude Crop Package

Dieses Paket ersetzt das vorherige Paket mit schlechten Crops.

## Enthalten

- Hauptbilder der Küche geschlossen/geöffnet
- komplette Detailkarten als Rohquelle
- Hotspot-Daten
- Crop-Hinweise für Claude
- ausführlicher Claude-Prompt

## Vorgehen

1. ZIP entpacken.
2. `docs/CLAUDE_PROMPT.md` an Claude geben.
3. Claude soll die Detailbilder selbst aus den Karten schneiden.
4. Claude soll die neue Sektion zusätzlich auf die Landingpage setzen.
5. Bestehende Inhalte dürfen nicht gelöscht oder ersetzt werden.

## Wichtig

Keine alten zugeschnittenen Detailbilder verwenden. In diesem Paket sind absichtlich keine Detail-Crops enthalten.
