# Claude-Auftrag: VIDEKO Exploding Kitchen zusätzlich auf Landingpage einbauen

## Wichtigster Grundsatz
Baue die neue **Exploding-Kitchen-Sektion zusätzlich** auf der Landingpage ein.

**Nicht löschen. Nicht ersetzen. Nicht umbauen.**  
Bestehende Inhalte, bestehende Sektionen, Header, Footer, Navigation, Tracking, Formulare und vorhandene Komponenten bleiben unverändert.

Die neue Sektion wird als eigener Block eingefügt. Geeignete Position: auf der Landingpage nach dem ersten starken Einstieg/Hero bzw. nach den ersten Kacheln/Leistungs-Teasern. Falls die Landingpage bereits eine klare Reihenfolge hat: den Block dort einfügen, wo eine große visuelle Premium-Sektion Sinn ergibt, aber keine bestehende Sektion entfernen.

---

## Ziel
Wir bauen eine interaktive **VIDEKO Exploding Kitchen Experience**.

Der Nutzer sieht eine hochwertige Küche. Per Toggle kann er zwischen zwei Ansichten wechseln:

1. **Ansicht „Geschlossen“**  
   Datei: `assets/main/kitchen_closed.png`

2. **Ansicht „Geöffnet“ / Exploding Kitchen**  
   Datei: `assets/main/kitchen_open_exploded.png`

Auf beiden Bildern liegen dieselben 8 Hotspots an denselben Prozent-Positionen. Beim Klick öffnet sich ein hochwertiges Modal/Slide-in mit:

- Titel
- kurzer Beschreibung
- 3 sauber ausgeschnittenen Detailbildern
- 3 Benefit-Punkten / Labels
- CTA-Button

Das Ganze soll wirken wie: **Premium Küchenstudio trifft interaktive Produktinszenierung.**  
Nicht wie Möbelhaus-PDF. Nicht wie Bastelstunde im Praktikum. Danke.

---

## Assets im Paket

### Hauptbilder
- `assets/main/kitchen_closed.png`
- `assets/main/kitchen_open_exploded.png`

### Detailkarten als Rohquelle
Diese Karten enthalten die benötigten Detailbilder. Bitte die benötigten Bildbereiche selbst sauber ausschneiden/exportieren.

- `assets/detail-cards/01_arbeitsplatte_materialien_card.png`
- `assets/detail-cards/02_kochfeld_insel_card.png`
- `assets/detail-cards/03_spuel_wasserzone_card.png`
- `assets/detail-cards/04_besteckauszug_card.png`
- `assets/detail-cards/05_topf_pfannenauszug_card.png`
- `assets/detail-cards/06_vorratsschrank_innenleben_card.png`
- `assets/detail-cards/07_scharniere_beschlaege_card.png`
- `assets/detail-cards/08_beleuchtung_atmosphaere_card.png`

### Daten
- `data/exploding-kitchen-hotspots.json`
- `data/card-crop-guidance.json`

---

## Sehr wichtig: Cropping
Die bisherigen Crops waren schlecht. Deshalb:

**Keine vorhandenen zugeschnittenen Bilder verwenden.**  
In diesem Paket sind absichtlich nur die Rohkarten enthalten.

Bitte schneide aus jeder Detailkarte selbst 3 saubere Detailbilder aus. Die Fotos dürfen keinen Text, keine Icons, keinen weißen Kartenrand und keine UI-Elemente enthalten.

Nutze `data/card-crop-guidance.json` nur als grobe Orientierung. Prüfe jeden Ausschnitt visuell und korrigiere ihn sauber. Lieber 5 Minuten länger schneiden als wieder digitale Wurstplatte.

Empfohlenes Ausgabeformat:

```txt
/public/images/exploding-kitchen/details/arbeitsplatte-materialien-01.webp
/public/images/exploding-kitchen/details/arbeitsplatte-materialien-02.webp
/public/images/exploding-kitchen/details/arbeitsplatte-materialien-03.webp
...
```

Alle Detailbilder möglichst einheitlich:

- Format: WebP
- Seitenverhältnis: ca. 4:3 oder 3:2
- Breite: ca. 900–1200 px
- Qualität: 85–90
- ohne Text im Bild
- ohne UI-Rand
- keine komischen halben Schriftzeilen

Falls automatisches Cropping nicht sauber ist: manuell nachjustieren.

---

## Hotspots
Nutze die Datei:

`data/exploding-kitchen-hotspots.json`

Die Positionen sind Prozentwerte bezogen auf das angezeigte Hauptbild:

```json
"position": { "x": 48, "y": 51 }
```

Bedeutet:

```css
left: 48%;
top: 51%;
```

Die Hotspots müssen auf beiden Ansichten identisch bleiben.

### Darstellung der Hotspots
Premium, nicht billig:

- kleiner runder Punkt mit feinem Gold-/Champagner-Akzent
- dezenter pulsierender Ring
- beim Hover: Label erscheint elegant
- beim Klick: Modal/Slide-in öffnet sich
- aktiver Hotspot darf stärker leuchten
- keine knalligen Farben
- keine Comic-Pins
- keine riesigen Marker, die die Küche verschandeln

Beispiel-Look:

```css
.hotspot {
  width: 18px;
  height: 18px;
  border-radius: 999px;
  background: #d8b46a;
  border: 2px solid rgba(255,255,255,.85);
  box-shadow: 0 0 0 8px rgba(216,180,106,.18), 0 12px 30px rgba(0,0,0,.25);
}
```

---

## Interaktion
### Ansicht wechseln
Oben oder innerhalb der Sektion einen hochwertigen Toggle bauen:

- „Geschlossen“
- „Geöffnet“

Beim Wechsel soll das Bild weich überblenden, nicht hart springen.

Gute Umsetzung:

```txt
Geschlossen  |  Geöffnet
```

Oder als Button:

```txt
Küche öffnen
```

Wenn man auf „Geöffnet“ klickt, wechselt das Hauptbild zur Exploding-Version. Die Hotspots bleiben exakt an ihren Positionen.

### Hotspot öffnen
Beim Klick auf Hotspot:

Desktop:
- Modal oder seitliches Slide-in rechts
- Hintergrund leicht abdunkeln / Küchenbild bleibt sichtbar
- Detailbild-Galerie oben oder rechts
- Text links/rechts sauber gegliedert

Mobil:
- Bottom-Sheet oder zentriertes Modal
- gut klickbare Buttons
- keine abgeschnittenen Inhalte
- Close-Button sichtbar

Funktionen:

- Klick außerhalb schließt Modal
- ESC schließt Modal
- Close-X schließt Modal
- Tastatur-Fokus beachten
- `aria-label` für Hotspots setzen
- Modal mit `role="dialog"` und `aria-modal="true"`

---

## Inhalt pro Hotspot
Die Inhalte kommen aus `data/exploding-kitchen-hotspots.json`.

Pro Hotspot anzeigen:

- `number`
- `category`
- `title`
- `description`
- 3 Detailbilder
- `bullets`
- CTA: `cta`

CTA kann intern auf Stylefinder/Beratung verlinken, falls es im Projekt schon eine Route gibt. Wenn nicht, Button erstmal auf die vorhandene Kontakt-/Beratungssektion scrollen lassen.

---

## Text für die Sektion
Nutze ungefähr diesen Inhalt, gern leicht passend an bestehende Tonalität anpassen:

### Eyebrow
`VIDEKO Exploding Kitchen`

### Headline
`Außen schön. Innen ziemlich clever.`

### Text
`Eine gute Küche erkennt man nicht nur an der Front. Erst wenn Auszüge, Beschläge, Stauraum, Licht und Material zusammenspielen, wird aus einer schönen Küche ein Raum, der jeden Tag funktioniert.`

### Button / Toggle-Hinweis
`Ansicht wechseln und Details entdecken.`

### Mini-Hinweis unter dem Bild
`Klicke auf die Punkte und entdecke, was in der Planung wirklich zählt.`

Darf gerne etwas VIDEKO-trocken sein, aber bitte hochwertig bleiben. Kein Kirmes-Sprech.

---

## Layout-Vorgaben
Die Website soll weiterhin VIDEKO wirken:

- oben/dort wo die Sektion sitzt: hell, clean, hochwertig
- warme Holz-/Steinfarben aus den Bildern aufnehmen
- dunkle Akzente sparsam nutzen
- Gold-/Champagner-Akzent nur dezent
- großzügige Abstände
- Bilder groß genug darstellen
- auf Desktop darf das Hauptbild richtig Bühne bekommen

### Desktop-Idee
```txt
[Eyebrow]
[Headline groß]                         [Toggle geschlossen/geöffnet]
[Text kurz]

[riesiges Küchenbild mit Hotspots über voller Breite]

[Mini-Hinweis / CTA-Zeile]
```

### Modal-Idee
```txt
[Nummer + Kategorie]
[Titel]
[Beschreibung]
[3 Detailbilder als Galerie]
[3 Benefits]
[CTA]
```

---

## Responsive Verhalten
### Desktop
- Hauptbild max. Breite ausnutzen
- Hotspots sauber relativ zum Bild platzieren
- Modal max. Breite ca. 980–1100 px oder Slide-in 520–640 px

### Tablet
- Bild bleibt groß
- Modal wird zentriert oder als breites Panel

### Mobile
- Hauptbild darf horizontal nicht kaputtgehen
- Hotspots kleiner, aber klickbar mindestens 36–44 px Touch-Fläche
- Modal als Bottom-Sheet oder Fullscreen-Lightbox
- Detailbilder als Swipe/Carousel oder vertikale Liste

Wichtig: Das Bild darf nicht so klein werden, dass man denkt, man schaut durch den Türspion ins Küchenstudio.

---

## Animationen
Dezent und hochwertig:

- Fade/scale-in für Sektion beim Scrollen
- weicher Bildwechsel beim Toggle
- Hotspot-Pulse langsam und ruhig
- Modal: slide/fade-in
- Detailbilder: leichter Hover-Zoom

Keine wilden Scroll-Jacking-Effekte. Kein Zwangs-Scrolling. Die Leute sollen weiter durch die Website kommen, ohne gegen eine Küchen-Wand zu laufen.

---

## Technische Umsetzung
Passe dich dem bestehenden Projekt an.

Falls React/Vite/Next/etc. vorhanden:
- eigene Komponente erstellen, z. B. `ExplodingKitchenSection`
- eigene CSS/SCSS-Datei oder bestehendes Styling-System nutzen
- Daten aus JSON importieren oder als lokales Array einbauen

Falls statische HTML/CSS/JS-Seite:
- eigenen Section-Block ergänzen
- eigenes JS-Modul oder Script unten ergänzen
- CSS sauber kapseln mit Prefix `.exploding-kitchen`

Keine unnötigen Libraries einbauen. Keine große Abhängigkeit für etwas, das mit normalem CSS/JS lösbar ist.

---

## Qualitätscheck vor Abschluss
Bitte nach dem Einbau prüfen:

- [ ] Bestehende Landingpage ist unverändert vorhanden
- [ ] Neue Sektion wurde zusätzlich eingefügt
- [ ] Toggle funktioniert
- [ ] Beide Hauptbilder laden korrekt
- [ ] 8 Hotspots sind sichtbar
- [ ] Hotspots liegen in beiden Ansichten an denselben Positionen
- [ ] Klick auf jeden Hotspot öffnet das passende Modal
- [ ] Jedes Modal hat 3 sauber zugeschnittene Detailbilder
- [ ] Keine Bildausschnitte enthalten Text, weiße Ränder oder UI-Elemente
- [ ] Modal schließt per X, außerhalb klicken und ESC
- [ ] Mobile Ansicht ist brauchbar
- [ ] Keine Console Errors
- [ ] Keine bestehende Sektion wurde gelöscht oder verschoben, außer wenn der Einfügepunkt minimal angepasst werden musste

---

## Schlussziel
Am Ende soll der Nutzer denken:

`Okay, die planen nicht nur Küchen. Die zeigen mir, warum eine Küche gut ist.`

Das Ding muss interaktiv, ruhig, teuer und sauber wirken. Keine Billig-Hotspot-Landkarte. Keine explodierte Küchen-Collage aus der Hölle.
