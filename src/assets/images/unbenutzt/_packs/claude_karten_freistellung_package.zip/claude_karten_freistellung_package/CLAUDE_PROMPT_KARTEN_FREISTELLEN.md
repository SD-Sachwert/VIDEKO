# Claude Prompt – Karten-Carousel technisch sauber überarbeiten

Bitte überarbeite **nur den Karten-/Benefit-Carousel-Baustein** in der gezeigten Sektion. **Nichts anderes auf der Seite löschen oder grundlegend verändern.** Ziel ist, dass die Karten hochwertiger, leichter und sauberer wirken.

## Ziel
Die sichtbaren Karten sollen **nicht mehr mit der großen weißen Rückplatte** ausgeschnitten sein, sondern **exakt entlang der eigentlichen Kartenkontur / Außenkante des Goldrands** freigestellt werden. Die Karten sollen dadurch cleaner, edler und weniger klobig wirken.

## Was konkret geändert werden soll
1. **Das weiße Backing hinter den Karten entfernen oder massiv reduzieren.**
   - Die Karten sollen nicht mehr wie auf eine weiße Platte gesetzt wirken.
   - Stattdessen sollen die Karten selbst die visuelle Form vorgeben.

2. **Jede Karte exakt bis zur Außenkante der Kartenform freistellen.**
   - Gemeint ist die äußere Kontur der sichtbaren Karte.
   - Der Goldrand bleibt vollständig sichtbar und sauber erhalten.
   - Keine zusätzlichen weißen Ränder außerhalb der eigentlichen Karte.

3. **Die Karten als transparente Assets behandeln.**
   - Wenn originale Assets vorliegen: jede Karte als PNG/WebP mit transparentem Hintergrund verwenden.
   - Wenn keine Einzelassets vorliegen: die Karten aus den vorhandenen Assets möglichst sauber neu erzeugen/freistellen.
   - Nicht einfach den kompletten Screenshot als Kachel verwenden.

4. **Tiefe nicht über eine weiße Platte erzeugen, sondern über Schatten und Bewegung.**
   - Nutze einen **subtilen, weichen Schatten** pro Karte.
   - Die aktive Karte darf etwas stärker angehoben wirken.
   - Die seitlichen Karten sollen dezenter und zurückgenommener sein.

## Gewünschte Optik
- **Aktive Karte (mittig):**
  - minimal größer skaliert
  - klar im Fokus
  - etwas stärkerer Schatten
  - volle Schärfe / volle Deckkraft
  - leicht angehobene Wirkung

- **Seitliche Karten:**
  - leicht kleiner
  - etwas weniger Deckkraft
  - optisch zurückgenommen
  - weicherer / schwächerer Schatten
  - dürfen leicht versetzt / überlappend stehen

## Wichtiger Qualitätsanspruch
Die Sektion soll wie ein **hochwertiges Premium-UI** wirken, nicht wie ein Mockup mit aufgeklebten Karten. Die Karten müssen leicht, elegant und sauber freigestellt aussehen.

## Interaktion
- Navigation und Logik des Carousels sollen erhalten bleiben.
- Hover / Fokus / aktiver Zustand sollen sauber und hochwertig wirken.
- Keine ruckeligen Übergänge.
- Animationen weich und dezent.

## Was du vermeiden sollst
- keine große weiße Rückplatte hinter den Karten
- keine harten oder schmutzigen Freistellkanten
- keinen sichtbaren weißen Rand außerhalb der eigentlichen Karte
- keine zu starken Schatten
- keine Veränderung anderer Seitensektionen

## Technische Erwartung
Bitte löse das so, dass:
- die Kartenform selbst die sichtbare Begrenzung ist
- transparente Assets unterstützt werden
- Schatten per CSS/Styling erzeugt werden
- aktive und inaktive Karten sauber über `scale`, `opacity`, `translate`, `z-index`, `filter` bzw. ähnliche Mittel gesteuert werden
- Layout und Responsiveness stabil bleiben

## Wenn du keine perfekten Einzelassets hast
Dann bitte trotzdem die Darstellung so umbauen, dass die Karten visuell **an der eigentlichen Kartenkante enden** und nicht an einer weißen Außenplatte. Falls nötig die Karten neu maskieren/freistellen oder als neue Einzel-Layer aufbauen.

## Ergebnis
Am Ende soll der Baustein deutlich hochwertiger aussehen:
- cleaner
- leichter
- mehr Premium
- weniger klobig
- bessere Tiefenwirkung trotz reduziertem Hintergrund
