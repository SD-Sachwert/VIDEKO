# Technische Anweisung – Karten bis zur Goldkante freistellen

## Kontext
Im aktuellen Zustand besitzen die Karten ein großes weißes Backing. Das wirkt unnötig klobig. Ziel ist eine Überarbeitung des Benefit-Card-Carousel, bei der die Karten **optisch exakt an ihrer äußeren Form** enden.

---

## Muss-Anforderungen

### 1) Asset-Handling
- Bevorzugt: jede Karte als **eigenes transparentes Asset** (PNG oder WebP).
- Freistellung exakt bis zur **äußeren Kartenkontur**.
- Der sichtbare Goldrahmen muss vollständig erhalten bleiben.
- Keine zusätzliche weiße Außenfläche als Bestandteil des Assets.

### 2) Rendering / UI
- Das aktuelle weiße Karten-Backing entfernen.
- Tiefe stattdessen über CSS-Schlagschatten und Layering erzeugen.
- Aktive Karte optisch priorisieren.
- Inaktive Karten sichtbar, aber klar zurückgenommen darstellen.

### 3) Motion / Interaction
- Sanfte Transitionen für `transform`, `opacity`, `filter`, `box-shadow`.
- Kein Springen beim Wechsel.
- Touch, Maus und Keyboard-Interaktion sollen sauber funktionieren.

### 4) Responsiveness
- Desktop: überlappende Kartenansicht beibehalten.
- Tablet/Mobile: Karten dürfen enger angeordnet werden, aber weiterhin mit sauberer Freistellung.
- Keine abgeschnittenen Schatten an Container-Grenzen.

---

## Soll-Optik

### Aktive Karte
- `scale`: leicht erhöht (z. B. 1.0 bis 1.03)
- `z-index`: höchste Ebene
- `opacity`: 1
- `filter`: keine oder minimale Reduktion
- `box-shadow`: weich, hochwertig, nicht zu hart
- optional: minimaler `translateY(-4px bis -8px)` oder äquivalenter Lift

### Seitliche Karten
- `scale`: leicht reduziert (z. B. 0.9–0.96)
- `opacity`: reduziert (z. B. 0.45–0.8 je nach Distanz)
- `z-index`: gestaffelt
- `filter`: bei Bedarf minimale Entsättigung oder softer Kontrast
- `box-shadow`: dezenter als bei der aktiven Karte

---

## Empfohlene Struktur

### DOM / Komponentenidee
- `carousel`
  - `carousel-track`
    - `card is-active`
    - `card is-prev`
    - `card is-next`
    - `card is-far-prev`
    - `card is-far-next`

### Pro Karte
- visuelles Kartenasset als transparentes Bild
- optional Text direkt im Asset oder innerhalb des Cardshells
- Schatten nicht in die Bilddatei backen, sondern nach Möglichkeit per CSS lösen

---

## CSS-/Styling-Richtung

Nutze z. B. folgende Prinzipien:
- `position: absolute` oder saubere transform-basierte Staffelung
- `transform: translateX(...) scale(...)`
- `transition: transform 350ms ease, opacity 350ms ease, filter 350ms ease, box-shadow 350ms ease;`
- `pointer-events` so setzen, dass aktive und anklickbare Seitenelemente sauber reagieren
- `overflow: visible`, damit Schatten und Staffelung nicht abgeschnitten werden

### Wichtig
Die Freistellung darf **nicht** durch einen simplen weißen Wrapper simuliert werden. Die äußere sichtbare Form muss die Karte selbst sein.

---

## Falls nur bestehende Bilder vorhanden sind
Wenn keine transparenten Einzelassets vorliegen:
1. vorhandene Kartengrafiken neu ausschneiden oder maskieren
2. auf saubere Kanten achten
3. weiße Außenplatte nicht wieder als Wrapper aufbauen
4. Schatten ausschließlich separat erzeugen

---

## QA / Abnahmekriterien
Der Umbau ist nur dann gut, wenn alle folgenden Punkte erfüllt sind:

- [ ] Karten enden sichtbar an ihrer eigentlichen Außenkontur
- [ ] Weiße Rückplatte ist entfernt oder optisch nicht mehr dominant
- [ ] Goldrahmen ist sauber sichtbar
- [ ] Aktive Karte wirkt hochwertig angehoben
- [ ] Seitliche Karten sind elegant zurückgenommen
- [ ] Schatten wirken weich und hochwertig
- [ ] Übergänge sind flüssig
- [ ] Kein Clipping an den Container-Rändern
- [ ] Auf Desktop und Mobile stabil
- [ ] Sonstige Seitenelemente wurden nicht verändert

---

## Kurzfassung für die Umsetzung
**Die Karten sollen nicht mehr als weiße Platten, sondern als sauber freigestellte Premium-Cards erscheinen. Tiefe über Schatten, Fokus über Scale/Opacity/Z-Index, kein grobes Backing.**
