# VIDEKO – Checkliste für Claude (nächste Runde)

## 1. Vorher/Nachher-Slider
- [ ] 12–20 sinnvolle Vorteilskarten / Hotspots eingebaut
- [ ] Ganzheitlicher Raumumbau klar kommuniziert
- [ ] Bild/Slider nicht markierbar
- [ ] Keine blaue Browser-Auswahl mehr
- [ ] Vorher/Nachher-Labels sichtbar genug
- [ ] Introblock oberhalb des Sliders zentriert

## 2. Studiokarten + Trenner
- [ ] Neuer eigenständiger Premium-Effekt für Studiokarten
- [ ] Nicht derselbe Effekt wie Karriere / Über uns
- [ ] Goldene Trenner global sauber übernommen
- [ ] Abstand von Trenner zu Content reduziert

## 3. Menschen-/Team-Kacheln
- [ ] Starker eigener Effekt für den Bereich „Menschen, die Küchen lieben“
- [ ] Bereich wirkt lebendiger / interaktiver
- [ ] CTA / Verlinkung zu „Über uns“ eingebaut

## 4. Video + Text-/Step-Bereich
- [ ] Video nicht über gesamte Breite gezogen
- [ ] Video hochwertig und kontrolliert eingebunden
- [ ] Linker Text-/Step-Balken gleiche Höhe wie rechtes Bild
- [ ] Bereich wirkt sauber ausbalanciert

## Global
- [ ] Mobile / Tablet / Desktop sauber geprüft
- [ ] Keine kaputten Layouts
- [ ] Animationen hochwertig und smooth
- [ ] VIDEKO-Look bleibt erhalten
