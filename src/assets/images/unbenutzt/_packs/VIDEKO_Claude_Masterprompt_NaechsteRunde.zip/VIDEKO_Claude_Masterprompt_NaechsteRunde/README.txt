# VIDEKO Claude Masterprompt – Nächste Runde

Inhalt dieser ZIP:
- `00_CLAUDE_MASTERPROMPT.txt`
- `01_CHECKLISTE.md`
- Ordner `screenshots/` mit Referenzbildern

Ziel:
Gezielte Überarbeitung mehrerer Bereiche der VIDEKO-Website.
Kein Komplett-Redesign, sondern starke Feinschliffe, bessere Effekte, saubere Layoutkorrekturen und klarere Kommunikation der Leistungen.
