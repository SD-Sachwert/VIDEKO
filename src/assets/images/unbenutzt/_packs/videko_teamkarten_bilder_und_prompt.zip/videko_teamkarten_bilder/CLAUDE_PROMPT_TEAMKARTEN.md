# Prompt für Claude – VIDEKO Teamkarten Bilder austauschen

Bitte tausche in der Sektion **„DAS TEAM HINTER VIDEKO / Mehr als nur drei Gründer.“** nur die sechs Kartenbilder aus. Nicht die gesamte Seite umbauen, nichts löschen, keine anderen Sektionen anfassen. Die Kartengröße, das 3-spaltige Raster, die Abstände, Rundungen und die grundsätzliche Typografie sollen so bleiben wie aktuell.

## Ziel
Die Karten sollen nicht mehr aussehen wie sechs gleiche dunkle Stockfotos mit demselben Farbverlauf. Jede Karte soll auf den ersten Blick eine andere Stimmung haben: hell, dunkel, Werkstatt, Büro, Social-Media-Setup, Kundenberatung. Mehr Abwechslung, mehr Leben, hochwertig, realistisch, ein bisschen charmant/humorvoll, aber weiterhin premium und nicht albern.

## Bilddateien verwenden
Lege die Bilder in den passenden Asset-Ordner und verwende sie exakt für diese Karten:

1. `01_beratung_planung.png` → **Beratung & Planung**
2. `02_marketing_social_media.png` → **Marketing & Social Media**
3. `03_montage_handwerk.png` → **Montage & Handwerk**
4. `04_sachbearbeitung_organisation.png` → **Sachbearbeitung & Organisation**
5. `05_partner_gewerke.png` → **Partner & Gewerke**
6. `06_service_nachbetreuung.png` → **Service & Nachbetreuung**

## Wichtig zur Darstellung
Die Karten sollen **genau die gleiche Größe wie vorher** behalten. Bitte keine Masonry-Karten, keine unterschiedlichen Kartenhöhen und kein neues Layout.

Nutze die Bilder als Card-Images mit:

```css
.team-card img,
.team-card-image {
  width: 100%;
  height: 100%;
  object-fit: cover;
  object-position: center;
  display: block;
}
```

Falls einzelne Bilder im breiten Kartenformat oben/unten ungünstig abgeschnitten werden, setze pro Bild ein passendes `object-position`, zum Beispiel:

```css
.beratung-planung img { object-position: center 45%; }
.marketing-social img { object-position: center 50%; }
.montage-handwerk img { object-position: center 52%; }
.sachbearbeitung img { object-position: center 50%; }
.partner-gewerke img { object-position: center 48%; }
.service-nachbetreuung img { object-position: center 45%; }
```

## Text-Overlay
Die bestehenden Kartentitel dürfen bleiben, aber bitte darauf achten, dass nichts doppelt oder chaotisch wirkt. Wenn die Bilder bereits sichtbaren Text im unteren Bereich enthalten, dann bitte entweder:

- den vorhandenen Website-Overlaytitel entfernen/ausblenden, **oder**
- den Website-Overlaytitel beibehalten und die Bildposition so wählen, dass der eingebrannte Bildtitel nicht störend sichtbar ist.

Mir ist wichtig: Am Ende darf pro Karte nicht zweimal derselbe Titel stehen. Das wäre optisch so unnötig wie ein 80er-Unterschrank mit drei Griffleisten.

## Optionaler Overlay für Lesbarkeit
Falls der Titel auf einzelnen Karten schlecht lesbar ist, bitte nur einen sehr dezenten dunklen Verlauf unten verwenden:

```css
.team-card::after {
  content: "";
  position: absolute;
  left: 0;
  right: 0;
  bottom: 0;
  height: 45%;
  background: linear-gradient(to top, rgba(0,0,0,.55), rgba(0,0,0,0));
  pointer-events: none;
}
```

Bitte keinen einheitlichen starken Schwarzfilter über alle Bilder legen. Genau das soll weg. Jedes Bild soll seinen eigenen Look behalten.

## Keine Änderungen an
- Header/Banner
- Texten oberhalb der Karten
- Seitenstruktur
- anderen Bereichen der Landingpage
- Animationen außerhalb dieser Karten

## Qualitätscheck
Nach dem Einbau bitte prüfen:

1. Alle sechs Karten sind gleich groß wie vorher.
2. Die Bilder sind deutlich abwechslungsreicher.
3. Keine Karte wirkt wie ein Duplikat der anderen.
4. Keine doppelten Kartentitel.
5. Mobile Ansicht bleibt sauber: 1 Spalte oder bestehendes responsives Verhalten beibehalten.
6. Keine weißen Bildränder, kein Verzerren, kein Quetschen.
