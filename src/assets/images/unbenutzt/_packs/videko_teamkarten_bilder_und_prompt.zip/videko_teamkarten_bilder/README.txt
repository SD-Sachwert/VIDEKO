VIDEKO Teamkarten – Austauschbilder

Enthalten:
- 6 Bilder im Ordner /images
- CLAUDE_PROMPT_TEAMKARTEN.md mit Einbau-Prompt

Die Bilder sind für die Teamkarten-Sektion gedacht:
Beratung & Planung, Marketing & Social Media, Montage & Handwerk, Sachbearbeitung & Organisation, Partner & Gewerke, Service & Nachbetreuung.
