# VIDEKO – Checkliste Runde 11

## Vorteile unter Startblock
- [ ] Desktop: 4 Vorteile wirklich nebeneinander
- [ ] Keine vertikale Stapelung auf Desktop
- [ ] Tablet: 2x2 okay
- [ ] Mobile: gestapelt okay
- [ ] Keine riesigen horizontalen Trennlinien zwischen den Items

## Post-it-Slider
- [ ] Obere Reihe leicht nach links verschoben
- [ ] Untere Reihe leicht nach links verschoben
- [ ] Texte bleiben vollständig lesbar
- [ ] Keine komplette Neuordnung

## Journal-Kacheln
- [ ] Alle Karten gleich hoch
- [ ] Bilder oben gleich hoch
- [ ] Textbereiche sauber
- [ ] CTAs unten bündig
- [ ] Keine abgeschnittenen Texte
