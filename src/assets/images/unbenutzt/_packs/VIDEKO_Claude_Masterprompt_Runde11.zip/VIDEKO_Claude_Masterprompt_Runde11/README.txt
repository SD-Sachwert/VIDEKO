# VIDEKO Claude Masterprompt – Runde 11

Inhalt:
- 00_CLAUDE_MASTERPROMPT.txt
- 01_CHECKLISTE.md
- screenshots/ mit Referenzbildern

Ziel:
Drei Korrekturen: Vorteile horizontal, Post-its feinjustieren, Journal-Karten gleich hoch.
