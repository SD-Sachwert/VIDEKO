# Claude Prompt – Bilder in den 3 Einstiegskarten austauschen

Bitte tausche **nur die Bilder / Bildassets** in den drei Einstiegskarten der Sektion **„Dein Weg zur Küche, die zu dir passt.“** aus.

## Wichtig
- **Keine anderen Inhalte, Texte, Buttons oder Layoutstrukturen ändern**, außer es ist technisch nötig, damit die neuen Bildformen sauber sitzen.
- Die drei neuen Bilder liegen als Dateien vor und sollen den bisherigen Kartenbildern zugeordnet werden.
- Die Bildwirkung soll hochwertig, modern, editorial und außergewöhnlich sein.
- Die **Besonderheit liegt in der äußeren Bildform**: keine klassische rechteckige Bildfläche, sondern eine **organische / asymmetrische Außenkontur**.
- Die Bilder sollen **genau in dieser Form sichtbar bleiben** und nicht wieder in ein normales Rechteck gezwungen werden.

## Zuordnung der Dateien
1. **01_inspiration_finden.png** → Karte **„Inspiration finden“**
2. **02_stylefinder_starten.png** → Karte **„Stylefinder starten“**
3. **03_persoenliche_beratung.png** → Karte **„Persönliche Beratung“**

## Was du konkret tun sollst
1. Ersetze in jeder der drei Karten das bisherige Bild durch die jeweils passende neue Datei.
2. Stelle sicher, dass die Bilder **nicht beschnitten werden wie normale rechteckige Thumbnails**, sondern ihre organische Außenform optisch erhalten bleibt.
3. Falls der bestehende Karten-Container aktuell auf rechteckige Bilder ausgelegt ist, passe die Bild-Einbindung so an, dass die neue Form sauber dargestellt wird.
4. Die Bilder sollen sauber, hochwertig und präsent wirken – keine verquetschte Skalierung, kein harter Beschnitt, keine unsauberen Kanten.
5. Die Karten sollen weiterhin als zusammengehörige Sektion funktionieren, aber jede davon soll visuell klar unterscheidbar sein.

## Gestalterische Anforderungen
- Die Bildfläche darf ruhig auffällig und untypisch wirken.
- Die äußere Form soll organisch / asymmetrisch bleiben.
- Gesamtlook: hochwertig, modern, weich, luxuriös, clean.
- Bitte keine zusätzlichen wilden Effekte, keine unnötigen Overlays und keine Stilbrüche.

## Technische Anforderungen
- Bildaustausch so umsetzen, dass die Datei-Zuordnung eindeutig bleibt.
- Responsiveness beibehalten.
- Auf Desktop und Mobile sauber darstellen.
- Keine Verzerrung der Bilder.
- Wenn nötig `object-fit`, Maskierung, Wrapper oder ähnliche Techniken anpassen, damit die organische Bildform korrekt dargestellt wird.
- Wenn Hover-Effekte vorhanden sind, sollen diese erhalten bleiben, aber die Bildform nicht zerstören.

## Ziel
Die drei Einstiegskarten sollen durch die neuen Bilder deutlich edler, individueller und weniger Standard-Webseiten-mäßig wirken. Die Bildform außenrum soll direkt auffallen und den Eindruck erzeugen: **„Okay, das sieht man nicht überall.“**
