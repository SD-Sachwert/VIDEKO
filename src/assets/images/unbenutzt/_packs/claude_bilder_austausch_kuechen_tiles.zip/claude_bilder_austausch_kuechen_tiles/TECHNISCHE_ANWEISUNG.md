# Technische Anweisung – Austausch der 3 Kartenbilder

## Dateizuordnung
- `01_inspiration_finden.png` → Karte 1 „Inspiration finden"
- `02_stylefinder_starten.png` → Karte 2 „Stylefinder starten"
- `03_persoenliche_beratung.png` → Karte 3 „Persönliche Beratung"

## Ziel
Die neuen Bilder besitzen eine organische asymmetrische Außenkontur und sollen genau so in die Karten eingebunden werden. Die Bildform ist gewollt und darf nicht durch einen normalen rechteckigen Karten-Image-Container zerstört werden.

## Muss-Anforderungen
- Bilder austauschen, ohne die Texte / CTA-Logik / Reihenfolge der Karten zu verändern.
- Die äußere Bildform sichtbar erhalten.
- Keine Rückwand, kein ungewollter harter Rahmen, kein Rechteck-Cropping.
- Keine Verzerrung.
- Responsives Verhalten beibehalten.

## Umsetzungs-Hinweis
Falls die Sektion aktuell klassische rechteckige `<img>`-Container nutzt, diese für die drei Bildbereiche anpassen.

### Bevorzugt
- Bild mit transparenter / organischer Kontur direkt einbinden.
- Wrapper so anpassen, dass `overflow`, `mask`, `clip-path`, `object-fit`, `aspect-ratio`, Positionierung und Skalierung sauber funktionieren.
- Außenabstände so setzen, dass die ungewöhnliche Form genug Luft bekommt.

### Falls nötig
- Für jede Karte eine leicht unterschiedliche Bildposition / Größe setzen, damit die Komposition sauber sitzt.
- Nur minimale Layoutanpassungen machen, damit alles sauber und hochwertig aussieht.

## Was NICHT geändert werden soll
- keine neuen Texte
- keine neue Kartenreihenfolge
- keine komplette Umgestaltung der Sektion
- keine Löschung anderer Bausteine

## Abnahmekriterien
- Alle 3 Karten zeigen die richtigen neuen Bilder.
- Die äußere organische Bildform bleibt sichtbar.
- Die Bilder wirken sauber integriert und hochwertig.
- Desktop und Mobile funktionieren.
- Nichts anderes auf der Seite wurde unnötig verändert.
