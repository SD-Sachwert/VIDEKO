# VIDEKO Claude Masterprompt Finalrunde

Diese ZIP enthält:
- 00_CLAUDE_MASTERPROMPT_FINALRUNDE.txt
- 01_CHECKLISTE.md
- screenshots/ mit Referenzen

Enthaltene Screenshots:
- 01_goldene_trenner_abstaende.png
- 02_hero_typografie.png
- 03_section_headline_typografie.png
- 04_vorher_nachher_slider.png
- 05_leistungssektionen_tauschen.png
- 06_video_groesser_bauen.png
- 07_teamkarten_dreheffekt.png
- 08_bewerbungsformular_anpassen.png
