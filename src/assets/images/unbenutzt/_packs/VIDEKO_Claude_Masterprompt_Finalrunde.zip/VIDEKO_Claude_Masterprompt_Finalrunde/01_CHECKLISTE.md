# VIDEKO Finalrunde – Checkliste

## Global
- [ ] Goldene Trenner aus Studioseite auf andere Seiten übertragen
- [ ] Zu große helle Leerräume reduziert
- [ ] Globale Typografie-Klassen erstellt/vereinheitlicht
- [ ] Hero-Headlines auf allen Seiten kleiner und gleichmäßiger
- [ ] Section-Headlines schwarz/gold einheitlich und proportional
- [ ] Mobile geprüft: 390, 430, 768 px, Desktop

## Vorher/Nachher-Slider
- [ ] Slider bewegt sich nur per Drag/Touch, nicht per Hover
- [ ] Vorher/Nachher-Labels sichtbar
- [ ] Handle klar sichtbar
- [ ] Viele sinnvolle Hotspots/Infoboxen ergänzt
- [ ] Ganzheitlicher Raumumbau kommt klar rüber
- [ ] Nicht überladen oder billig

## Leistungsseite
- [ ] „Weniger Chaos…“ vor „Deine neue Küche…“ gesetzt
- [ ] Prozessliste auf 7 Punkte erweitert
- [ ] Nachbetreuung & Ansprechpartner ergänzt
- [ ] Fake-Zahl „98 % zufriedene Kunden“ entfernt
- [ ] Ehrliche Claim-Zahlen eingefügt

## Video-Sektion
- [ ] Video deutlich größer
- [ ] Breites Videoformat genutzt
- [ ] Text sinnvoll als Overlay oder daneben/darüber gelöst
- [ ] Sektion wirkt wie Feature, nicht wie kleines Bild

## Über uns
- [ ] Teamkarten-Raster aufgewertet
- [ ] Eigener Flip-/Tilt-/Reveal-Effekt, nicht gleiche Lösung wie Karriere
- [ ] Inhalte bleiben korrekt

## Karriere Formular
- [ ] Formular rechts ungefähr gleiche Höhe wie linker Block
- [ ] „Bereich“ zu „Wunschbereich“
- [ ] Telefon nicht optional, Beispielnummer als Placeholder
- [ ] Upload-Label ohne „optional“
