# Claude Prompt – VIDEKO Modul „Finde die 8 Küchensünden“ auf Journal-Seite „7 Küchenfehler"

Baue auf unserer bestehenden Website **nur** auf der Journal-Seite **„7 Küchenfehler“** ein neues interaktives Modul ein. Das Modul soll optisch und technisch hochwertig wirken und sich sauber in das bestehende VIDEKO-Design einfügen. **Nichts anderes löschen oder verschlechtern.** Header, Footer, globale Navigation, bestehende Styles und andere Seiten bitte unangetastet lassen.

## Ziel
Wir wollen auf der Journal-Seite ein interaktives Suchspiel integrieren:
**„Finde die 8 Küchensünden“**
Der Nutzer klickt in ein Küchenbild und entdeckt 8 versteckte Planungsfehler. Das Modul soll Spaß machen, Kompetenz zeigen und am Ende in einen Lead-CTA übergehen.

## Wichtig
- Nicht als großes blockierendes Modal bauen.
- Kein Popup in der Mitte, das alles überlagert.
- Die Infokarte soll sich **direkt aus dem getroffenen Hotspot heraus schieben** bzw. direkt daneben erscheinen.
- Der Nutzer soll danach **sofort einen anderen Hotspot anklicken können**, ohne erst etwas separat schließen zu müssen.
- Wenn ein anderer Hotspot angeklickt wird, ersetzt dessen Karte die vorherige offene Karte.
- Das Ganze muss hochwertig, flüssig und sauber animiert wirken.
- Desktop first, aber mobil ebenfalls ordentlich umsetzen.

## Zu verwendende Assets
Nutze die mitgelieferten Dateien aus diesem Paket:
- `01_reference_full_mockup.png` = Gesamtstil und Zielbild
- `02_kitchen_scene_main_desktop.png` = Hauptbild für das interaktive Suchspiel
- `03_cta_banner_bg_dark.png` = Hintergrundbild für den unteren CTA-Bereich
- `04_ui_kit_reference.png` = Komponenten- und Stilreferenz

## Inhalt und Aufbau der Sektion
Baue die Seite so auf, in dieser Reihenfolge:

### 1) Intro / Headline-Bereich
- Kleines Badge: „INTERAKTIV“
- Große Headline: **„Finde die 8 Küchensünden“**
- Subline: **„Klicke in die Küche und finde die Planungsfehler, die im Alltag wirklich nerven.“**

### 2) Hauptmodul mit 2 Spalten
#### Links
Großes interaktives Küchenbild (`02_kitchen_scene_main_desktop.png`)
- Keine sichtbaren Nummern im Startzustand.
- Hotspots sind zunächst unsichtbar.
- Bei Hover am Desktop ganz leichte visuelle Rückmeldung möglich (subtil).
- Bei Klick auf richtigen Bereich:
  - goldener Marker erscheint an der Stelle
  - kleine dunkle Info-Karte fährt direkt am Hotspot auf
  - Eintrag wird rechts als gefunden markiert
  - Fortschritt erhöht sich
- Bei Klick auf falschen Bereich:
  - kleine dunkle Karte „Knapp vorbei …“ mit humorvoller Microcopy
  - ebenfalls nicht zentriert, sondern lokal am Klickpunkt / sinnvoll in der Nähe

#### Rechts
Sticky oder visuell stabile Sidebar-Karte mit:
- Überschrift: „Ihr Fortschritt“
- großer Status: „0 von 8 gefunden“ / dynamisch
- Progressbar
- 8 kleine Kreise für den Fortschritt
- Primärbutton: **„Hinweis anzeigen“**
- Sekundärbutton: **„Alle Fehler aufdecken“**
- Bereich „Bereits gefunden“
- kleine Reward-Karte:
  - Titel: „Kleine Belohnung“
  - Text: **„Wer alle 8 findet, versteht Küchenplanung besser als so mancher Prospekt. 😉“**

### 3) Kleiner Hinweistext unter dem Hauptbild
Text z. B.:
**„Klicke in die Küche, um versteckte Planungsfehler zu entdecken.“**
Darunter kleiner Statushinweis wie:
**„Schon 0 von 8 gefunden – weiter so!“**

### 4) Bereich „So funktioniert’s“
Drei Karten nebeneinander:
1. **Küche untersuchen** – „Klicke dich durch die Küche und schau genau hin – die Fehler sind gut versteckt.“
2. **Fehler finden** – „Entdecke alle 8 Planungsfehler, die den Alltag später unnötig erschweren.“
3. **Besser planen** – „Verstehe typische Stolperfallen – und plane deine Küche von Anfang an richtig.“

### 5) Bereich „Welche Sünden verstecken sich?“
Zeige 8 Themen-Kacheln / Icons:
- Arbeitsfläche
- Laufwege
- Licht
- Steckdosen
- Stauraum
- Müllsystem
- Geräteposition
- Ergonomie

### 6) Unterer CTA-Bereich
Nutze `03_cta_banner_bg_dark.png` als Hintergrund.
Text:
- Headline: **„Alle 8 gefunden?“**
- Subheadline: **„Dann wird’s Zeit für die echte Planung.“**
- Text: **„Wir verwandeln dein Spielerlebnis in eine maßgeschneiderte Küche, die wirklich zu dir, deinem Alltag und deinem Raum passt.“**
- Button: **„Kostenlosen Küchencheck starten“**
- Kleine Benefits darunter: **Unverbindlich**, **Individuell**, **Persönlich**

## Stil / Look & Feel
- VIDEKO Premium-Look
- oben dunkel, Hauptbereich hell, sauber und elegant
- Farben grob wie Referenz:
  - Gold: `#B8862B`
  - Helles Beige / Off-White: `#F6F2EC`
  - Schwarz / Anthrazit: `#111111`
- große elegante Typo für Headlines
- viel Luft und Weißraum
- runde Ecken, feine Border, dezente Schatten
- keine billige Gamification-Optik
- kein Möbelhaus-Ramsch, kein Kirmes-Gefühl

## Interaktion / Verhalten
### Richtige Treffer
Für korrekte Hotspots sollen diese Titel und Erklärungstexte erscheinen:
1. **Zu wenig Arbeitsfläche**  
   „Die Arbeitsfläche ist zu knapp bemessen. Das macht Kochen und Vorbereiten im Alltag schnell unpraktisch.“
2. **Müllsystem ungünstig platziert**  
   „Wenn der Müll zu weit weg oder ungeschickt sitzt, wird jeder Handgriff unnötig umständlich.“
3. **Schwaches Arbeitslicht**  
   „Gute Küchenbeleuchtung ist kein Deko-Thema. Wer schlecht sieht, arbeitet schlechter.“
4. **Steckdosen nicht da, wo man sie braucht**  
   „Kleingeräte brauchen Strom an sinnvollen Stellen – nicht erst nach einer Kabel-Expedition.“
5. **Laufwege unpraktisch**  
   „Zwischen Kühlen, Spülen und Kochen sollte die Küche mitdenken – nicht gegen dich arbeiten.“
6. **Geräteposition unergonomisch**  
   „Wenn Geräte zu tief oder unglücklich sitzen, nervt dich das jeden einzelnen Tag.“
7. **Stauraum nicht clever genutzt**  
   „Schöner Look bringt wenig, wenn Stauraum verschenkt wird oder Dinge schwer erreichbar sind.“
8. **Ergonomie nicht mitgedacht**  
   „Gute Planung fühlt sich im Alltag leicht an. Schlechte Planung merkt man bei jedem Griff.“

### Falsche Klicks
Nutze mehrere rotierende Microcopy-Varianten, z. B.:
- „Knapp vorbei. Die Pflanze ist unschuldig.“
- „Schöner Versuch. Aber das ist diesmal nicht der Übeltäter.“
- „Sieht verdächtig aus, ist aber unschuldig.“
- „Fast. Da liegt der Hund heute nicht begraben.“

## Technik
- Sauber in die bestehende Seite integrieren.
- Bitte responsiv bauen.
- Auf Mobile dürfen Hotspots etwas großzügiger und einfacher anklickbar sein.
- Auf Mobile darf die Sidebar unter das Bild rutschen.
- Keine Layout-Sprünge.
- Animationen dezent und schnell.
- Buttons und Interaktion barrierearm aufbauen.
- Gerne mit lokalem State / leichtem JS.

## Sehr wichtig
- Bitte wirklich **nur diese Journal-Seite erweitern**.
- Nichts anderes kaputt machen.
- Das Modul soll wie ein bewusst geplanter Premium-Baustein wirken – nicht wie ein nachträglich drangeklebtes Gimmick.

Nutze die mitgelieferten Bilder und orientiere dich optisch sehr nah an der Referenz.
