VIDEKO – Paket „Finde die 8 Küchensünden"

Inhalt:
01_reference_full_mockup.png       -> Gesamtziel / Layoutreferenz
02_kitchen_scene_main_desktop.png  -> Hauptbild für das interaktive Suchspiel
03_cta_banner_bg_dark.png          -> Hintergrund für unteren CTA-Bereich
04_ui_kit_reference.png            -> UI-Komponentenreferenz
PROMPT_CLAUDE_JOURNAL_7_KUECHENFEHLER.md -> Hauptprompt für Claude
HOTSPOTS_AND_COPY.json             -> Texte, Hotspots, Hinweise und Microcopy

Hinweis:
Die Hotspot-Koordinaten sind Startwerte auf Basis des gelieferten Bildes.
Claude soll sie beim Einbau visuell feinjustieren.
