VIDEKO Karriere – Job-Stage Assets für Claude

Inhalt:
- 00_CLAUDE_PROMPT_KARRIERE_JOB_STAGE.txt
- images/jobcards/01–06: fertige helle Jobkarten im gewünschten Stil
- references/current_old_job_grid_block.png: alter Block als Negativ-/Ausgangspunkt
- references/reference_extreme_dark_variant.png: ursprüngliche wilde Variante, nur als Idee
- references/reference_clean_stage_variant.png: ruhigere Stage-Referenz

Wichtig für Claude:
Die Jobkarten sind keine reinen Fotos, sondern fertige visuelle Karten. Nicht denselben Text erneut über die Bilder legen, außer Claude baut die Karten komplett in HTML/CSS nach.
