# Kurze Umsetzungskontrolle

- [ ] Filterchips entfernt
- [ ] Keine große Kachelwand mehr
- [ ] Immer nur eine aktive Rolle sichtbar
- [ ] Heller Marble-Gold-Hintergrund
- [ ] Kartenstapel/Deck rechts oder dezente Step-Navigation
- [ ] Smooth Card-Swap Animation
- [ ] Mobile ohne Horizontal Overflow
- [ ] Initiativbewerben-CTA vorhanden
- [ ] Humorvolle Microcopy vorhanden
- [ ] Keine doppelten Texte über den Kartenbildern
