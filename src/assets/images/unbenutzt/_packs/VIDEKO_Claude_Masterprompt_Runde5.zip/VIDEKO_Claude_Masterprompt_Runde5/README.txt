# VIDEKO Claude Masterprompt – Runde 5

Inhalt:
- 00_CLAUDE_MASTERPROMPT.txt
- 01_CHECKLISTE.md
- screenshots/ mit Referenzbildern

Referenzen:
- 01_karten_nicht_beschneiden.png
- 02_postits_um_komplettes_bild_neues_vorherbild.png
- 03_alten_3_karten_block_entfernen.png
- 04_neue_einstiegssektion_ueber_slider.png
- 05_divider_auch_unterseiten.png

Ziel:
Gezielte Anpassungen an Karten, Slider/Post-it-Bereich, Exploding Kitchen, Landingpage-Einstieg und goldenen Dividern.
