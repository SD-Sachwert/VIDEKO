# VIDEKO – Checkliste für Claude Runde 5

## 1. Karten
- [ ] Kartenbilder werden vollständig angezeigt
- [ ] Obere goldene Linie ist nicht abgeschnitten
- [ ] Kein unerwünschtes Cropping
- [ ] Container / object-fit sauber angepasst

## 2. Slider / Exploding Kitchen
- [ ] Post-its um alle vier Seiten des Bildes angeordnet
- [ ] Post-its wirken natürlich, leicht wild, hochwertig
- [ ] Neues Bild `01_hero_leerer_raum_desktop` als Vorher-Bild genutzt
- [ ] Landingpage zeigt Exploding Kitchen zuerst normal
- [ ] Alternative Ansicht erst nach Button/Toggle

## 3. Alter 3-Karten-Block
- [ ] Alter rechteckiger Block mit Inspiration / Stylefinder / Beratung entfernt
- [ ] Keine leere Fläche hinterlassen
- [ ] Abstände sauber korrigiert

## 4. Neue Einstiegssektion
- [ ] Neue organische 3-Karten-Sektion über Slider/Post-it-Küche verschoben
- [ ] Headline in Richtung „Womit möchtest du starten?“ geändert
- [ ] Sektion wirkt als Einstieg / Startpunkt

## 5. Goldene Divider
- [ ] Kurze goldene Divider auf Karriereseite eingebaut
- [ ] Kurze goldene Divider auf Leistungsseite eingebaut
- [ ] Kurze goldene Divider auf Über-uns-Seite eingebaut
- [ ] Divider global einheitlich in Länge, Farbe, Stärke und Abstand

## Global
- [ ] Mobile / Tablet / Desktop geprüft
- [ ] Keine Layoutbrüche
- [ ] VIDEKO-Look bleibt erhalten
