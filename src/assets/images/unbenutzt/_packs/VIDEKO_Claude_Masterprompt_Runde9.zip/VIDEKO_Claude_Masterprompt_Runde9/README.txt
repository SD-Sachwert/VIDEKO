# VIDEKO Claude Masterprompt – Runde 9

Inhalt:
- 00_CLAUDE_MASTERPROMPT.txt
- 01_CHECKLISTE.md
- screenshots/ mit Referenzbildern

Ziel:
Gezielte Korrekturen an Post-it-Slider, Vorteilsleiste, Prozessblock, Standortbereich, FAQ-Akkordeon und Button-Hover.
