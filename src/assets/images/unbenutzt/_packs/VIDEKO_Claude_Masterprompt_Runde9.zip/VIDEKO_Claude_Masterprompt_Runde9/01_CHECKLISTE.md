# VIDEKO – Checkliste Runde 9

## Slider / Post-its
- [ ] Post-its weiter nach außen geschoben
- [ ] Post-its dürfen über Bildcontainer hinausragen
- [ ] Alle Texte lesbar
- [ ] Keine verdeckten oder abgeschnittenen Karten

## Vier Vorteile unter Slider
- [ ] Desktop: 4 Vorteile nebeneinander
- [ ] Tablet: ggf. 2x2
- [ ] Mobile sauber gestapelt
- [ ] Texte passen zum Slider / Raumumbau

## Prozessblock
- [ ] Linke Step-Liste und rechter Detailbereich gleich hoch
- [ ] Beide Seiten schließen bündig ab
- [ ] Keine gequetschte Optik

## Standortbereich
- [ ] Standort-Pin auf Karte entfernt
- [ ] Linker Text gekürzt
- [ ] Text klingt nicht nach nur Würzburg/Umland
- [ ] Klar: VIDEKO arbeitet regional und darüber hinaus

## FAQ
- [ ] Nur angeklicktes FAQ-Item öffnet
- [ ] Keine Kopplung zwischen linker und rechter Spalte
- [ ] Eigener State / Identifier pro FAQ-Item

## Buttons
- [ ] Buttons driften beim Hover nicht mehr weg
- [ ] Hover-Effekt hochwertig: Glow / Schatten / Licht
- [ ] Maximal minimale Bewegung
- [ ] Pfeil darf subtil animieren, Button nicht flüchten
- [ ] Global auf allen Seiten geprüft
