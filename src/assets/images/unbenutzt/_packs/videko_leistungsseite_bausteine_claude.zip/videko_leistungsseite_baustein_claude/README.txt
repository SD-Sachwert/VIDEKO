Inhalt der ZIP:
- 8_leistungskarten/01_beratung_und_planung.png
- 8_leistungskarten/02_aufmass_und_3d_planung.png
- 8_leistungskarten/03_materialien_und_auswahl.png
- 8_leistungskarten/04_lichtplanung_und_ambiente.png
- 8_leistungskarten/05_lieferung_und_montage.png
- 8_leistungskarten/06_geraete_und_technik.png
- 8_leistungskarten/07_koordination_und_gewerke.png
- 8_leistungskarten/08_nachbetreuung_und_service.png
- referenz_screenshots/09_prozess_timeline_baustein.png
- referenz_screenshots/10_vorteile_benefits_baustein.png
- claude_prompt_leistungsseite_neuer_aufbau.txt

Ziel:
Claude soll die Leistungsseite neu aufbauen mit folgender Reihenfolge:
1. Bestehender Video-Baustein oben bleibt.
2. Neuer interaktiver 8-Leistungs-Baustein.
3. Prozess-/Timeline-Baustein.
4. Vorteile-/Benefits-Baustein.
5. Bestehender „Klassisch geplant oder VIDEKO geplant?“-Vergleich bleibt am Ende erhalten.
