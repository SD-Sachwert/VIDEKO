INHALT DES PAKETS

00_zielbild_big_hero_mockup.png
= Zielbild / visuelle Referenz, wie die Section am Ende aussehen soll.

01_hero_leerer_raum.png
= Before-Bild für das große Vorher/Nachher-Hero.

02_hero_fertige_kueche.png
= After-Bild für das große Vorher/Nachher-Hero.

03_karte_inspiration_materialien.png
= Bild für Karte 01 „Inspiration finden“.

04_karte_stylefinder.png
= Bild für Karte 02 „Stylefinder starten“.

05_karte_beratung.png
= Bild für Karte 03 „Persönliche Beratung“.

CLAUDE_PROMPT_BIG_HERO.txt
= Exakter Prompt für Claude zum Umbau der Section.
