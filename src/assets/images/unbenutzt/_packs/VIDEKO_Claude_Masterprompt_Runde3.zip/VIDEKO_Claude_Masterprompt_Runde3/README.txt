# VIDEKO Claude Masterprompt – Runde 3

Inhalt dieser ZIP:
- `00_CLAUDE_MASTERPROMPT.txt`
- `01_CHECKLISTE.md`
- `screenshots/` mit Referenzbildern

Ziel:
Gezielte Überarbeitung mehrerer Bereiche der VIDEKO-Website.
Kein Komplett-Redesign, sondern sauberer Feinschliff mit klaren Vorgaben zu Video-Größen, Teamblock, Divider-System und Slider-Aufbau.
