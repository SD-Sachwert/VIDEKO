# VIDEKO – Checkliste für Claude (Runde 3)

## 1. Video-Sektionen
- [ ] Studio-Video nicht mehr full-width
- [ ] Leistungsseiten-Video etwas größer
- [ ] Beide Videos in einheitlicher Container-Logik
- [ ] Gleiche Max-Width / Radius / Abstände / responsive Regeln

## 2. Über uns / Teamblock
- [ ] Teamblock auf 6 Karten erweitert
- [ ] Neuer Baustein „Service & Nachbetreuung“ ergänzt
- [ ] Alle 6 Karten gleich groß
- [ ] „Route planen“ entfernt
- [ ] Goldenen Divider auf halbe Länge gekürzt
- [ ] Goldenen Mini-Divider global übernommen

## 3. Slider-Bereich
- [ ] Text-/Chip-Reihe unter dem Slider entfernt
- [ ] Vorteile als weiße Post-its / Infobausteine rund um das Bild platziert
- [ ] Slider etwas größer gemacht
- [ ] Vorher-/Nachher-Labels im Slider entfernt

## Global
- [ ] Mobile / Tablet / Desktop geprüft
- [ ] Keine Layoutbrüche
- [ ] Animationen hochwertig und smooth
- [ ] VIDEKO-Look bleibt erhalten
