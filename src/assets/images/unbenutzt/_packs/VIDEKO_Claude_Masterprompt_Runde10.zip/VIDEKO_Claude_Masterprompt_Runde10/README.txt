# VIDEKO Claude Masterprompt – Runde 10

Inhalt:
- 00_CLAUDE_MASTERPROMPT.txt
- 01_CHECKLISTE.md
- screenshots/ mit Referenzbildern

Ziel:
Gezielte Korrekturen an Start-/Stylefinder-Block, Post-it-Slider, Prozess-Mini-Slider und Karten-Carousel.
