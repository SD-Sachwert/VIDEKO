# VIDEKO – Checkliste Runde 10

## Start-/Stylefinder-Block
- [ ] Gesamter Block kompakter
- [ ] Panels/Karten kleiner und weniger wuchtig
- [ ] Vorteile auf Desktop nebeneinander
- [ ] Tablet 2x2 / Mobile sauber gestapelt

## Post-it-Slider
- [ ] Post-its weiter auseinandergezogen
- [ ] Alle Post-it-Texte lesbar
- [ ] Rahmen bleibt lebendig und leicht schräg
- [ ] Maßzahlen 3,20 / 5,10 / 2,80 entfernt

## Prozess-Step 06
- [ ] Mini-Slider funktioniert wirklich
- [ ] Mouse und Touch funktionieren
- [ ] Handle gut greifbar
- [ ] Kein Überlaufen aus der Karte

## Karten-Carousel
- [ ] Weißer Schleier/Halo bei allen Karten entfernt
- [ ] Karte 03 als optische Referenz genutzt
- [ ] Karten etwas größer
- [ ] Linker Text ragt nicht in Karten hinein
- [ ] Keine Überlagerungen
